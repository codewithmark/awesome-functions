<?php

//--->absolute url path > start

//Site Name
define("SiteName", 'Awesome Functions');

//libs folder
define("ABSPATH_Folder_Path_Libs", ABSPATH.'/_inc/libs');

//rotues folder
define("ABSPATH_Folder_Path_Routes", ABSPATH.'/routes');
 


//views folder
define("ABSPATH_Folder_Path_Views", ABSPATH.'/views'); 
//views folder
define("ABSPATH_Folder_Path_Func", ABSPATH.'/_inc/func');

 
//404 error page
define("ABSPATH_404_Page", ABSPATH_Folder_Path_Views.'/404.php'); 

//--->absolute url path > end



//--->client/browser url path > start

//this will be used for browser urls

define("URL_View", APPURL.'/views'); 
  

//--->client/browser url path > end



//for url routing
include_once ABSPATH_Folder_Path_Libs.'/class_AltoRouter.php';

//for connecting to the database
include_once ABSPATH_Folder_Path_Libs.'/class_SimpleDBClass.php';

//for sending emails
include_once ABSPATH_Folder_Path_Libs.'/class_simple_sendy.php';



//functions
include_once ABSPATH_Folder_Path_Func.'/func-00-data-minig.php';
include_once ABSPATH_Folder_Path_Func.'/func-01-date-time.php';
include_once ABSPATH_Folder_Path_Func.'/func-02-hash.php';
include_once ABSPATH_Folder_Path_Func.'/func-03-token.php';
include_once ABSPATH_Folder_Path_Func.'/func-04-files-folder.php';
include_once ABSPATH_Folder_Path_Func.'/func-05-ip-location.php';
include_once ABSPATH_Folder_Path_Func.'/func-06-curl.php';
include_once ABSPATH_Folder_Path_Func.'/func-07-url.php';
include_once ABSPATH_Folder_Path_Func.'/func-08-validator.php';






?>