<?php


//--->minifier > html > start
function app_minify_html($buffer)
{ 
  $buffer =preg_replace('/<!--(.*?)-->/', '', $buffer);
  $buffer =preg_replace('/\>\s*\</', '><', $buffer);
  return $buffer; 
}
 
//--->minifier > html > end


//--->minifier > js > start 
function app_minify_js($input) 
{
    if(trim($input) === "") return $input;
    return preg_replace(
        array(
            // Remove comment(s)
            '#\s*("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')\s*|\s*\/\*(?!\!|@cc_on)(?>[\s\S]*?\*\/)\s*|\s*(?<![\:\=])\/\/.*(?=[\n\r]|$)|^\s*|\s*$#',
            // Remove white-space(s) outside the string and regex
            '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/)|\/(?!\/)[^\n\r]*?\/(?=[\s.,;]|[gimuy]|$))|\s*([!%&*\(\)\-=+\[\]\{\}|;:,.<>?\/])\s*#s',
            // Remove the last semicolon
            '#;+\}#',
            // Minify object attribute(s) except JSON attribute(s). From `{'foo':'bar'}` to `{foo:'bar'}`
            '#([\{,])([\'])(\d+|[a-z_][a-z0-9_]*)\2(?=\:)#i',
            // --ibid. From `foo['bar']` to `foo.bar`
            '#([a-z0-9_\)\]])\[([\'"])([a-z_][a-z0-9_]*)\2\]#i'
        ),
        array(
            '$1',
            '$1$2',
            '}',
            '$1$3',
            '$1.$3'
        ),
    $input);
}


//--->minifier > js > end

//--->minifier > css > start
function app_minify_css($str)
{
    $str = preg_replace('!/\*.*?\*/!s', '', $str);
    $str = preg_replace('/\s*([{}|:;,])\s+/', '$1', $str);
    $str = preg_replace('/\s\s+(.*)/', '$1', $str);
    $str = str_replace(';}', '}', $str);
    return trim($str);
}
//--->minifier > css > end


function app_get_file_data($dir,$file_ext)
{
    $arr = array();
    $ffs = scandir($dir);   

    $str = '';
    foreach($ffs as $ff) 
    {
        if($ff != '.' && $ff != '..') 
        {    
            $filename =  $ff;
            $ext = substr($filename,strrpos($filename,'.',-1),strlen($filename));  
            if($ext ==$file_ext)
            {                 
                $str .= (file_get_contents($dir.$filename))."\n" ;                 
            }
        }
    }
    $str .= '';
    return $str;
}

function app_load_page_files($dir,$file_ext)
{
    $arr = array();
    $ffs = scandir($dir);   

    foreach($ffs as $ff) 
    {
        if($ff != '.' && $ff != '..') 
        {    
            $filename =  $ff;
            $ext = substr($filename,strrpos($filename,'.',-1),strlen($filename));  
            if($ext ==$file_ext)
            {   
                
                if($file_ext == ".js")
                {
                    //minify_js
                    //echo app_minify_js (file_get_contents($dir.$filename))."\n";
                    echo  (file_get_contents($dir.$filename))."\n";
                    //need this to ensure there is no code break
                    
                }
                else if($file_ext == ".css")
                {
                    echo  app_minify_css(file_get_contents($dir.$filename))."\n";
                    //need this to ensure there is no code break
                
                }
                else
                {
                    echo  app_minify_html(file_get_contents($dir.$filename))."\n";
                }
                
            }
        }
    }
}

?>