<?php

function app_db ()
{
    if(file_exists(ABSPATH.'/app-config.php'))
    { 
    	include_once ABSPATH.'/app-config.php';
	    $db_conn = array(
	        'host' => DB_HOST, 
	        'user' => DB_USER,
	        'pass' => DB_PASSWORD,
	        'database' => DB_NAME, 
	    );
	    $db = new SimpleDBClass($db_conn);

	    return $db; 
	 }   
}

//--->size > start

function app_size($collection)
{
    /*
        This function will find the size of: string, integer and array
    */
    $get_data_type = gettype($collection);
    if($get_data_type == 'string' || $get_data_type == 'integer')
    {
        return strlen($collection);
    }
    else if($get_data_type == 'array')
    {
        return count($collection);
    }
}
//--->size > end

//--->find > start

function app_find($collection,$find_val = array())
{    
    /*
        This function will find an array from a list of arrays

        i.e. Find(array_collection, array('option_name' =>'app_name' , ))[0]['option_value'];
    */
    if(app_size($find_val) >0 )
    {    
        $a = array();       
        foreach($find_val as $k1=>$v1)
        {
            foreach($collection as $k2=>$v2)
            { 
                if( $v2[$k1] == $v1 ) 
                {
                    $a[]=$v2;
                }
            }
        }       
        if(app_size($a) > 0)
        {
          return $a;   
        }
        else
        {
            return false;
        }
             
    }
}
//--->find > end 


function app_validate_entries ($reqest_type, $entries = array())
{
    /*
        call it like this:
        validate_entries($_POST/$_GET, array('id', 'user_name'));

        //if you want to set error code, then call it like this:
        validate_entries($_POST/$_GET, array('id', 'user_name'));
    */
    foreach ($entries as $v1) 
    {
        if(!isset( $reqest_type[$v1]))
        {
            header("HTTP/1.1 600 Missing API Variable");

            echo json_encode(array(
                'status' =>"error", 
                'http_code'=> 600,
                'code' => 'missing_parameter',
                'missing_parameter_name' =>  $v1,
               
                'msg' => 'missing > '. $v1,
                
            ));
            die();          
        }
    }
}



function app_echo_json ($message = null, $code = 200)
{
    $status = array(
        200 => '200 OK',
        400 => '400 Bad Request',
        422 => 'Unprocessable Entity',
        500 => '500 Internal Server Error',
        600 => '600 Missing API Variable',
        601 => '601 No Data Found',
    );
    $get_code = isset($status[$code]) ? $status[$code] : $code;
    header("HTTP/1.1 ". $get_code );
    echo json_encode($message );
    die();
}

 

?>