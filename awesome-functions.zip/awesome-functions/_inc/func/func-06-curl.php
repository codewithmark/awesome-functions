<?php

function app_api_call( $call_method,$api_url, $post_data_array = array(),  $header = array()) 
{
    //Encode the array into JSON.
    $jsonDataEncoded = json_encode($post_data_array);

    //Initiate cURL.
    $curl = curl_init($api_url);
 

    //Tell cURL that we want to send a POST request.
    curl_setopt($curl, CURLOPT_POST, 1);

    //Attach our encoded JSON string to the POST fields.
    curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonDataEncoded);
    
    //call type > GET, PUT, POST, DELETE and etc
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, strtoupper($call_method));

    curl_setopt($curl, CURLOPT_HTTPHEADER,$header);
    
    //return the transfer data from the api url
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
    
    //Set the content type to application/json
    //curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    
    //User agent... use this if you are doing some maching botting(fasting data rabbing)
    curl_setopt($curl, CURLOPT_USERAGENT, app_get_random_user_agent());
    
   // Timeout in seconds   
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);

    //Execute the request
    $response = curl_exec($curl);
    
    //get the http header code... i.e. 200, 301
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    
    curl_close($curl);
    
    //convert it into php array to make it easier to parse data
    //return json_decode($response,true);
    //return $response;
    return array('http_code'=> $http_code, 'data' =>  json_decode($response,true));
}

function app_get_random_user_agent()
{
    $userAgents=array(
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
        "Opera/9.20 (Windows NT 6.0; U; en)",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; en) Opera 8.50",
        "Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.1) Opera 7.02 [en]",
        "Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; fr; rv:1.7) Gecko/20040624 Firefox/0.9",
        "Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/48 (like Gecko) Safari/48"       
    );
    $random = rand(0,count($userAgents)-1); 
    return $userAgents[$random];
}
?>