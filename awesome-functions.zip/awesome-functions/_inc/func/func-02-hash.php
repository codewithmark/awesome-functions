<?php




function app_hash_password($Password)
{  
  /*    
    More hash options - https://codewithmark.com/best-option-for-hashing-your-passwords-in-php
  */

  $Code = hash('sha512', $Password);  
  return $Code;
}

function app_hash($hash_string,$hash_name = 'crc32')
{
  return hash($hash_name,$hash_string);   
}

function app_auto_hash($has_name = 'crc32') 
{   
    
  $alphanum = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  $special  = '~!@#$%^&*(){}[],./?';
  $bin2hex  = bin2hex(app_random_string(100));
  $alphabet = $alphanum . $special .   $bin2hex;

  //This WILL make sure the auto code is random!!!    
  $String = $alphabet.mt_rand().microtime().uniqid();

  //if $_hash_name is "crc32", it wil return 8 characters long auto code        
  return hash($has_name,$String);       
}


function app_random_string($length = 4) 
{
  $str = "";
  $characters = array_merge(range('A','Z'), range('a','z'), range('0','9'));
  $max = count($characters) - 1;
  for ($i = 0; $i < $length; $i++) 
  {
      $rand = mt_rand(0, $max);
      $str .= $characters[$rand];
  }
  return $str;
}

?>