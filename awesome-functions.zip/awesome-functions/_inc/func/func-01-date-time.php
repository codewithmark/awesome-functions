<?php

function app_convert_time_stamp($user_datetime,$format_type='')
{
    $date = new DateTime($user_datetime);
    //$future_timestamp =$date->format('c');

    $time_stamp_iso = $date->format('c');
    $time_stamp_unix = $date->format('U');

    $time_stamp = $date->format('Y-m-d H:i:s');
    $date = $date->format('Y-m-d');

    if($format_type == "iso")
    {
        return $time_stamp_iso;
    }
    elseif($format_type == "unix")
    {
        return $time_stamp_unix;
    }
    elseif($format_type == "dttm")
    {
        return $time_stamp;
    }
    elseif($format_type == "dt")
    {
        return $date;
    }
    else
    {
        return $time_stamp;
    }
}

function app_get_time_stamp($format_type='')
{
    $time_stamp_iso = date('c');
    $time_stamp_unix = date('U');

    $time_stamp = date('Y-m-d H:i:s');
    $date = date('Y-m-d');

    if($format_type == "iso")
    {
        return $time_stamp_iso;
    }
    elseif($format_type == "unix")
    {
        return $time_stamp_unix;
    }
    elseif($format_type == "dttm")
    {
        return $time_stamp;
    }
    elseif($format_type == "dt")
    {
        return $date;
    }
    else
    {
        return $time_stamp;
    }
}

function app_get_future_date ($day_num = 1)
{    
    $future_timestamp = date( "U", strtotime('+'.$day_num.' days' ) );
    return $future_timestamp;
}

function app_microtime_microseconds()
{
    list($usec, $sec) = explode(" ", microtime());
    return round(($usec * 1000) + $sec);
}

function app_date_diff_in_days($date1, $date2 = "" )  
{ 
    /*
        // Start date 
        $date1 = "2019-07-01"; 
          
        // End date 
        $date2 = "2019-07-05";
        
        $d = app_date_diff_in_days($date1,$date2);

        //output : +4


    */
    $dt_2 = $date2 != "" ? $date2 : date( "Y-m-d");
    // Creates DateTime objects 
    $datetime1 = date_create($date1); 
    $datetime2 = date_create($dt_2); 


    // Calculates the difference between DateTime objects 
    $interval = date_diff($datetime1, $datetime2); 

    // Display the result 
    $d1 = $interval->format("%R%a"); 


    return $d1;

}



?>