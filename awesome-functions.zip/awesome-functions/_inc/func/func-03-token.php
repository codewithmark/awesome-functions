<?php

//--->token > start

//below functions are used for login tokens

function app_token_set($token_name, $token_value)
{
    app_session ('set', $token_name, $token_value );
}

function app_token_get($token_name)
{
    if(app_session('get',$token_name)) 
    {
        return app_session ('get', $token_name);
    }
}

function app_token_check($token_name)
{
    //check to see if user logged in     
    if(!app_session('get',$token_name)) 
    { 
        echo json_encode (array
        (
            'status'=>'error',
            'msg'=>'missing api '.$token_name.' token'
        ));
        
        die();

    }       
}

function app_token_delete($token_name)
{
    //check to see if user logged in    
    return app_session ('delete', $token_name);
}

function app_token_destroy()
{
    //check to see if user logged in    
    return app_session ('destroy' );
}

function app_session($method='get',$session_name = '', $session_value = '' )
{    
    // Start the session 
    if (!isset($_SESSION) && !isset($_SESSION[$session_name])) session_start();

    $GetMethod = strtolower($method);

    //Add a session
    if($GetMethod =='set')
    {
        //session_start();
       $_SESSION[$session_name] = $session_value;
       return true;
    }

    //Get a session
    if($GetMethod =='get')
    {
        if(isset($_SESSION[$session_name]))
        {
            return  $_SESSION[$session_name];
        }        
    }

    //Delete a session
    if($GetMethod =='delete')
    {
        //check to see if user logged in     
        if(isset($_SESSION[$session_name]))
        {
            //URLRedirect(Admin_URL);
            unset($_SESSION[$session_name]);  
            return true;       
        }         
    }
    
    //Delete all sessions
    if($GetMethod =='destroy')
    {
        if (isset($_SESSION))
        {
            // remove all session variables
            session_unset(); 

            // destroy the session 
            session_destroy(); 
  
            return true;
        }
    }
}
//--->token > end

?>