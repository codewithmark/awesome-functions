<?php

function app_user_agent()
{    
    return $_SERVER['HTTP_USER_AGENT'];
}

//--->URL Redirect - Start
function app_url_redirect($URL)
{
    ob_start();
    // End automatic output buffering
    ob_end_clean(); 
     
    //Redirect to dashbord
    header('Location: ' . $URL);    
}
//--->URL Redirect - End


//--->Get Domain Name - Start
function app_get_domain_name($url)
{
    $host = @parse_url($url, PHP_URL_HOST);
    // If the URL can't be parsed, use the original URL
    // Change to "return false" if you don't want that
    if (!$host)
        $host = $url;
    // The "www." prefix isn't really needed if you're just using
    // this to display the domain to the user
    if (substr($host, 0, 4) == "www.")
        $host = substr($host, 4);
    // You might also want to limit the length if screen space is limited
    if (strlen($host) > 50)
        $host = substr($host, 0, 47) . '...';
    return $host;
}
//--->Get Domain Name - End


//--->Get Referer URL - Start
function app_get_ref_domain()
{
    $GetRefURL = isset($_SERVER['HTTP_REFERER']);   
    if($GetRefURL)
    {
        $URL = app_get_domain_name($_SERVER["HTTP_REFERER"]);
    }
    else if(!$GetRefURL)
    {
        $URL = 'direct'; 
    }
    return $URL; 
}

function app_get_ref_url()
{
    $GetRefURL = isset($_SERVER['HTTP_REFERER']);   
    if($GetRefURL)
    {
        $URL = $_SERVER["HTTP_REFERER"];
    }
    else if(!$GetRefURL)
    {
        $URL = 'direct'; 
    }
    return $URL; 
}
//--->Get Referer URL - End

?>