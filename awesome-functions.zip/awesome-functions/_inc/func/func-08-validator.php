<?php

 
function app_is_ip($ip)
{
	//is it > ip
    if(filter_var($ip, FILTER_VALIDATE_IP)) return true;
}

function app_is_email($value)
{
	//is it > email
    if(filter_var($value, FILTER_VALIDATE_EMAIL)) return true;
}


function app_is_url($value)
{
	if(filter_var($value, FILTER_VALIDATE_URL)) return true;
}

function app_is_int($value)
{
	//is it > integer
    if(filter_var($value, FILTER_VALIDATE_INT)) return true;
}


function app_is_bool($value)
{
	if(is_bool(filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE))) return true;
}


 
function app_is_alphanum($value)
{
    if(filter_var($value, FILTER_VALIDATE_REGEXP, array('options' => array('regexp' => "/^[a-zA-Z0-9]+$/")))) return true;
}

function app_is_alpha($value)
{
    if(filter_var($value, FILTER_VALIDATE_REGEXP, array('options' => array('regexp' => "/^[a-zA-Z]+$/")))) return true;
}

function app_is_float($value)
{
    if(filter_var($value, FILTER_VALIDATE_FLOAT)) return true;
}

?>