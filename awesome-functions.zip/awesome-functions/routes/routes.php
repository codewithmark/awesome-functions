<?php


$router->map( 'GET', '/', function() 
{
	$app_name = "Awesome Functions"; 
	
	//ob_start("app_minify_js");
	//ob_start("app_minify_html");
	include_once ABSPATH_Folder_Path_Views.'/home.php';
});

$router->map( 'GET', '/[*:id]', function($id) 
{
	$route_id = $id;
 
	$routes = array("storage", "api", "jquery", "bootstrap", 'form', 'easy-validator');

	if (in_array($route_id, $routes))
	{
		$app_name = "Awesome Functions"; 
		include_once ABSPATH_Folder_Path_Views.'/'.$route_id.'.php';
	}
	else
	{
		include_once ABSPATH_404_Page;
	}
});


?>