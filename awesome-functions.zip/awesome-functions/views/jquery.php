<!DOCTYPE html>
<html>
<head>

	<title>jQuery - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This JS library has a lot of useful and powerful JS and PHP functions that will help you build awesome client side web applications">
 
	
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{
		//console.clear(); 
      $('[data-toggle="tooltip"]').tooltip();
	
		
		//Example for charount function
		js.CharCount($(".TCharCount"), 100);
		
		$(document).on('click', '.btn_TableToJSON', function(event) 
		{
			if( $('.TableJsonCounter').html() =='')	 
			{
				var data = js.TableToJSON($('#mdata'));
            console.log("Table To JSON Arrray ", data)            
            $('.TableJsonCounter').html('1') 
			}
		});
 

		
	});
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row"> 

		<div class="col-md-9">
		<h1 class="text-center">jQuery</h1>	
		<p  class="text-center">These functions have dependency on jQuery</p> 

						<!--[GetFileExt - Start]-->
			<span class="ScrollTo_SEO"  id="SEO" ></span>
			<h3  class="page-header">SEO</h3> 
			<p>This is one of the most powerful function. With just one line of code you will be able to :</p>

			<ul>
				<li>Add  open in new window and nofollow to all external links</li>
				<li>Hide href links(downloadable links) that have file extensions (zip ,rar, mp3, mp4 pdf, docx, pptx, xlsx, js, css)</li>
				<li>Add alt tags to all of your images.</li>
			</ul>

			<b>Usage</b>			 
<pre class="bg-success ">
//Just put this at the top of your page 
js.SEO(); 

//If you want remove "nofollow" from your external links, just: follow="yes" in your a tags
//example
&lt;a href="http:/codewithmark.com/" follow="yes"> Follow Link Example&lt;/a>
</pre> 
			<b>Example</b>
			<br>
	 
			<a href="https://apimk.com/" >No Follow Link Example</a>
			<br>
			<a href="http://codewithmark.com/" follow="yes" > Follow Link Example</a>
			<!--[GetFileExt - End]-->
			
			
			<!--[Int - Start]-->
			<span class="ScrollTo_Int"  id="Int" ></span>
			<h3  class="page-header" >Int </h3>
			<p>This will convert your string into a number</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.Int (StringVal)

js.Int ("1505")
 
//--->Out put will
1505 as number 
</pre>
			<!--[Int - End]-->

			<!--[AutoCode - Start]-->
			<span class="ScrollTo_AutoCode" id="AutoCode" ></span>
			<h3  class="page-header">AutoCode</h3>
			<p>This will generate a random string which will have numbers and letters(upper and lower case)</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.AutoCode(n)

//n is length of characters

//If n is null, the default will be 8 characters long

//Method 1
js.AutoCode () //--->Out put: h0wgHPcy

//Method 2
js.AutoCode (10) //--->Out put: w02eo8kLRv
</pre>
			<!--[AutoCode - End]-->

		<!--[Template - Start]-->
		<span class="ScrollTo_Template" id="Template" ></span>
		<h3  class="page-header">Template</h3>
		<p>With this template function you can easily create your own templates like "Mustache"</p>
		<p>Let's suppose for a second you have the following div</p>
<pre>
&lt;div class="MKClass">
 &lt;div class="ClassName">Hello my name is: UserName and my favorite food is UserFood &lt;/div>
&lt;/div>
</pre>
		<p>You have a user that you want replace "UserName" with the person's name and "UserFood" with the food that person likes.</p>

		<p>You can easily do that with this function</p>
		
			<b>Usage</b>			 

<pre class="bg-success ">
//Your template div container
&lt;div class="TemplateDiv">Hello my name is: {UserName} and my favorite food is {UserFood} &lt;/div>


//Your output div... where you are going to show your user info
&lt;div class="UserDiv">&lt;/div>

//Function Syntax
js.Template (ObjArr,StringData)

var ObjArr =
{  
  "{UserName}":"Mark Kumar", 
  "{UserFood}":"Fast Food"
};

var strContent = $('.TemplateDiv').html();

//Create user content
var NewContent = js.Template (ObjArr,strContent);

//Out put user content
$('.UserDiv').html(NewContent);

//Out put will be
&lt;div class="UserDiv">
Hello my name is: Mark Kumar and my favorite food is Fast Food
&lt;/div>
</pre>
		<p>You can easily run the same process for 10 people</p>

<pre class="bg-success "> 
//Assuming you have your data in an array like below

var UserData = 
[
  {name: "Mike", food: "Pizza"},
  {name: "Jack", food: "Chocolate"},
  {name: "Bob", food: "Ice Cream"},
  {name: "Rob", food: "Bacon"},
  {name: "Mark", food: "Burgers"},
  {name: "Jane", food: "Chicken"},
  {name: "Lisa", food: "French Fries"},
  {name: "Tara", food: "Tacos"},
  {name: "John", food: "Sushi"}, 
]

for(var i =0; i < UserData.length; i++)
{
  var ObjArr =
  {  
    "{UserName}":UserData[i].name, 
    "{UserFood}":UserData[i].food,
  };

  var strContent = $('.TemplateDiv').html();
 
  //Create user content
  var NewContent = js.Template (ObjArr,strContent);

  //Out put user content
  $('.UserDiv').append(NewContent);
}
</pre>
<p>Unlike other libraries, you can only do this on page load. But with Template Function, you can dynamically do this.</p>

<p>Also, with this function you have the flexibility to modify the template parameter.</p>
<p> For example, instead of using &ldquo;{parameter }&rdquo;, you can use &ldquo;{{parameter }}&rdquo; or &ldquo;{{{parameter}}}&rdquo; or &ldquo;|||parameter|||&rdquo; or &nbsp;&ldquo;{-&gt; parameter&lt;-}&rdquo; or anything else you would like.</p>

			<!--[Template - End]-->
			
			<!--[Change Page Title - Start]-->
			<span class="ScrollTo_ChangePageTitle" id="ChangePageTitle" ></span>
			<h3  class="page-header">Change Page Title</h3>
			<p>This will change the title of the page dynamically</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.ChangePageTitle (strNewPageTitle)

//Before call
&lt;title>Some page title&lt;/title>
 
//Call it like this
js.ChangePageTitle ('Awesome Functions')

//After call
&lt;title>Awesome Functions&lt;/title>
 
</pre>
			<!--[Change Page Title - End]-->
			
			
			<!--[Get Date Time - Start]-->
			<span class="ScrollTo_FormatDateTime" id="FormatDateTime"></span>
			<h3  class="page-header">Format Date Time</h3>
			<p>This function was built upon <a href="http://momentjs.com/docs/#/displaying/">moment js</a> </p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.FormatDateTime  (value,FormatType) 

//With no value
js.FormatDateTime  ('','YYYY-MM-DD')  //--->Out put: YYYY-MM-DD
js.FormatDateTime  ('','MM-DD-YYYY h:mm:ss')  //--->Out put: MM-DD-YYYY h:mm:ss
js.FormatDateTime  ('','MM-DD-YYYY')  //--->Out put: MM-DD-YYYY

//Current date/time
var now = new Date();

//With values
js.FormatDateTime (now,'YYYY-MM-DD')  //--->Out put: YYYY-MM-DD
js.FormatDateTime (now,'MM-DD-YYYY h:mm:ss')  //--->Out put: MM-DD-YYYY h:mm:ss
js.FormatDateTime (now,'MM-DD-YYYY')  //--->Out put: MM-DD-YYYY
</pre>
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_DateTimeFormatType" aria-expanded="false" aria-controls="Collapse_DateTimeFormatType" >Out Put Format Types</a>			
			<div class="collapse" id="Collapse_DateTimeFormatType">
				<br>	
				
				<table class="table table-striped table-bordered">
   <tbody>
      <tr>
         <th></th>
         <th>FormatType</th>
         <th>Output</th>
      </tr>
      <tr>
         <td><b>Month</b></td>
         <td>M</td>
         <td>1 2 ... 11 12</td>
      </tr>
      <tr>
         <td></td>
         <td>Mo</td>
         <td>1st 2nd ... 11th 12th</td>
      </tr>
      <tr>
         <td></td>
         <td>MM</td>
         <td>01 02 ... 11 12</td>
      </tr>
      <tr>
         <td></td>
         <td>MMM</td>
         <td>Jan Feb ... Nov Dec</td>
      </tr>
      <tr>
         <td></td>
         <td>MMMM</td>
         <td>January February ... November December</td>
      </tr>
      <tr>
         <td><b>Quarter</b></td>
         <td>Q</td>
         <td>1 2 3 4</td>
      </tr>
      <tr>
         <td></td>
         <td>Qo</td>
         <td>1st 2nd 3rd 4th</td>
      </tr>
      <tr>
         <td><b>Day of Month</b></td>
         <td>D</td>
         <td>1 2 ... 30 31</td>
      </tr>
      <tr>
         <td></td>
         <td>Do</td>
         <td>1st 2nd ... 30th 31st</td>
      </tr>
      <tr>
         <td></td>
         <td>DD</td>
         <td>01 02 ... 30 31</td>
      </tr>
      <tr>
         <td><b>Day of Year</b></td>
         <td>DDD</td>
         <td>1 2 ... 364 365</td>
      </tr>
      <tr>
         <td></td>
         <td>DDDo</td>
         <td>1st 2nd ... 364th 365th</td>
      </tr>
      <tr>
         <td></td>
         <td>DDDD</td>
         <td>001 002 ... 364 365</td>
      </tr>
      <tr>
         <td><b>Day of Week</b></td>
         <td>d</td>
         <td>0 1 ... 5 6</td>
      </tr>
      <tr>
         <td></td>
         <td>do</td>
         <td>0th 1st ... 5th 6th</td>
      </tr>
      <tr>
         <td></td>
         <td>dd</td>
         <td>Su Mo ... Fr Sa</td>
      </tr>
      <tr>
         <td></td>
         <td>ddd</td>
         <td>Sun Mon ... Fri Sat</td>
      </tr>
      <tr>
         <td></td>
         <td>dddd</td>
         <td>Sunday Monday ... Friday Saturday</td>
      </tr>
      <tr>
         <td><b>Day of Week (Locale)</b></td>
         <td>e</td>
         <td>0 1 ... 5 6</td>
      </tr>
      <tr>
         <td><b>Day of Week (ISO)</b></td>
         <td>E</td>
         <td>1 2 ... 6 7</td>
      </tr>
      <tr>
         <td><b>Week of Year</b></td>
         <td>w</td>
         <td>1 2 ... 52 53</td>
      </tr>
      <tr>
         <td></td>
         <td>wo</td>
         <td>1st 2nd ... 52nd 53rd</td>
      </tr>
      <tr>
         <td></td>
         <td>ww</td>
         <td>01 02 ... 52 53</td>
      </tr>
      <tr>
         <td><b>Week of Year (ISO)</b></td>
         <td>W</td>
         <td>1 2 ... 52 53</td>
      </tr>
      <tr>
         <td></td>
         <td>Wo</td>
         <td>1st 2nd ... 52nd 53rd</td>
      </tr>
      <tr>
         <td></td>
         <td>WW</td>
         <td>01 02 ... 52 53</td>
      </tr>
      <tr>
         <td><b>Year</b></td>
         <td>YY</td>
         <td>70 71 ... 29 30</td>
      </tr>
      <tr>
         <td></td>
         <td>YYYY</td>
         <td>1970 1971 ... 2029 2030</td>
      </tr>
      <tr>
         <td></td>
         <td>Y</td>
         <td>1970 1971 ... 9999 +10000 +10001
            <br>
            <b>Note:</b> This complies with the ISO 8601 standard for dates past the year 9999
         </td>
      </tr>
      <tr>
         <td><b>Week Year</b></td>
         <td>gg</td>
         <td>70 71 ... 29 30</td>
      </tr>
      <tr>
         <td></td>
         <td>gggg</td>
         <td>1970 1971 ... 2029 2030</td>
      </tr>
      <tr>
         <td><b>Week Year (ISO)</b></td>
         <td>GG</td>
         <td>70 71 ... 29 30</td>
      </tr>
      <tr>
         <td></td>
         <td>GGGG</td>
         <td>1970 1971 ... 2029 2030</td>
      </tr>
      <tr>
         <td><b>AM/PM</b></td>
         <td>A</td>
         <td>AM PM</td>
      </tr>
      <tr>
         <td></td>
         <td>a</td>
         <td>am pm</td>
      </tr>
      <tr>
         <td><b>Hour</b></td>
         <td>H</td>
         <td>0 1 ... 22 23</td>
      </tr>
      <tr>
         <td></td>
         <td>HH</td>
         <td>00 01 ... 22 23</td>
      </tr>
      <tr>
         <td></td>
         <td>h</td>
         <td>1 2 ... 11 12</td>
      </tr>
      <tr>
         <td></td>
         <td>hh</td>
         <td>01 02 ... 11 12</td>
      </tr>
      <tr>
         <td></td>
         <td>k</td>
         <td>1 2 ... 23 24</td>
      </tr>
      <tr>
         <td></td>
         <td>kk</td>
         <td>01 02 ... 23 24</td>
      </tr>
      <tr>
         <td><b>Minute</b></td>
         <td>m</td>
         <td>0 1 ... 58 59</td>
      </tr>
      <tr>
         <td></td>
         <td>mm</td>
         <td>00 01 ... 58 59</td>
      </tr>
      <tr>
         <td><b>Second</b></td>
         <td>s</td>
         <td>0 1 ... 58 59</td>
      </tr>
      <tr>
         <td></td>
         <td>ss</td>
         <td>00 01 ... 58 59</td>
      </tr>
      <tr>
         <td><b>Fractional Second</b></td>
         <td>S</td>
         <td>0 1 ... 8 9</td>
      </tr>
      <tr>
         <td></td>
         <td>SS</td>
         <td>00 01 ... 98 99</td>
      </tr>
      <tr>
         <td></td>
         <td>SSS</td>
         <td>000 001 ... 998 999</td>
      </tr>
      <tr>
         <td></td>
         <td>SSSS ... SSSSSSSSS</td>
         <td>000[0..] 001[0..] ... 998[0..] 999[0..]</td>
      </tr>
      <tr>
         <td><b>Time zone</b></td>
         <td>z or zz</td>
         <td>
            EST CST ... MST PST
            <br>
         </td>
      </tr>
      <tr>
         <td></td>
         <td>Z</td>
         <td>-07:00 -06:00 ... +06:00 +07:00</td>
      </tr>
      <tr>
         <td></td>
         <td>ZZ</td>
         <td>
            -0700 -0600 ... +0600 +0700
         </td>
      </tr>
      <tr>
         <td><b>Unix Timestamp</b></td>
         <td>X</td>
         <td>1360013296</td>
      </tr>
      <tr>
         <td><b>Unix Millisecond Timestamp</b></td>
         <td>x</td>
         <td>1360013296123</td>
      </tr>
   </tbody>
</table>
						 
			</div> 
			
			<!--[Get Date Time - End]-->

			<!--[Get Future Date - Start]-->
			<span class="ScrollTo_GetFutureDate" id="GetFutureDate"></span>
			<h3  class="page-header">Get Future Date</h3>
			<p>This will get a future date</p>
			<p>Note: The Format Type is the same as "Format Date Time" function (above) </p>
			 

			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
 js.GetFutureDate  (DaysIntoFuture,FormatType)

//Call it like this
js.GetFutureDate (2,'YYYY-MM-DD')  //--->Out put: YYYY-MM-DD 
 
js.GetFutureDate (7,'MM-DD-YYYY')  //--->Out put: MM-DD-YYYY 
</pre>
			<!--Get Future Date - End]-->
 
			
			<!--[Character Count - Start]-->
			<span class="ScrollTo_CharCount"  id="CharCount" ></span>
			<h3  class="page-header">Character Count</h3>
			<p>This will allow you to limit the number of characters your user can type in a textarea</p>

			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.CharCount (ElementID,TotalCharsAllowed)
 

//Call it like this
js.CharCount($(".TCharCount"), 100);
 
</pre>
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CharCount" aria-expanded="false" aria-controls="Collapse_CharCount" >Example</a>			
			<div class="collapse" id="Collapse_CharCount">
				 <textarea rows="4" cols="50" class="TCharCount" placeholder="type your text here... limit is 100 characters"></textarea>	
			</div> 
			<!--[Character Count - End]-->
		
			<!--[IsOnline - Start]-->
			<span class="ScrollTo_IsOnline"  id="IsOnline" ></span>
			<h3  class="page-header">Is Online</h3>
			<p>This will tell you if your user is online or offline</p>

			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.IsOnline() //Out will be: online or offline 
</pre> 
			<!--[IsOnline - End]-->
			
			<!--[GetFolderPath - Start]-->
			<span class="ScrollTo_GetFolderPath"  id="GetFolderPath" ></span>
			<h3  class="page-header">Get Folder Path</h3>
			<p>This will get the current folder path of the url</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.GetFolderPath() 

//Will get the path to current folder.
//i.e. if url is: http://codewithmark.com/download/123.mp3 
//will return http://codewithmark.com/download/
</pre> 
			<!--[GetFolderPath - End]-->
		
			<!--[GetSiteURL - Start]-->
			<span class="ScrollTo_GetSiteURL"  id="GetSiteURL" ></span>
			<h3  class="page-header">Get Site URL</h3>
			<p>This will get the current site url</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.GetSiteURL() //output http://www.awesomefunctions.com/
</pre> 
			<!--[GetSiteURL - End]-->
		 
		 
		  <!--[CapitalizeFirstLetter - Start]-->
			<span class="ScrollTo_CapitalizeFirstLetter"  id="CapitalizeFirstLetter" ></span>
			<h3  class="page-header">Capitalize First Letter</h3>
			<p>This will capitalize first letter of the word</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.CapitalizeFirstLetter(Word)

js.CapitalizeFirstLetter('code with mark'); //output:  Code With Mark
</pre> 
			<!--[CapitalizeFirstLetter - End]-->
			
			<!--[GetFileName - Start]-->
			<span class="ScrollTo_GetFileName"  id="GetFileName" ></span>
			<h3  class="page-header">Get File Name</h3>
			<p>This will get the file name from url path</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.GetFileName(FileURL); 

js.GetFileName("http://codewithmark.com/download/123.mp3");

//output:  123
</pre> 
			<!--[GetFileName - End]-->
			
						
			<!--[GetFileExt - Start]-->
			<span class="ScrollTo_GetFileExt"  id="GetFileExt" ></span>
			<h3  class="page-header">Get File Ext</h3>
			<p>This will get the file ext from url path</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
js.GetFileExt(FileURL); 

js.GetFileExt("http://codewithmark.com/download/123.mp3");

//output:  mp3
</pre> 
			<!--[GetFileExt - End]-->
			
			<!--[URL - Start]-->
			<span class="ScrollTo_URL"  id="URL" ></span>
			<h3  class="page-header">URL</h3>
			<p>This will get the url and hash</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax  
js.URL(Parametter); 

//Method 1 
js.URL("host"); //output: http://www.awesomefunctions.com

//Method 2
js.URL("hostname"); //output: http://www.awesomefunctions.com

//Method 3 
js.URL("hash"); 
//if url is : http://www.awesomefunctions.com/jquery#Template
//output will: #Template
 
</pre> 
			<!--[URL - End]-->

         <!--[URL - Start]-->
         <span class="ScrollTo_PrettyURL"  id="PrettyURL" ></span>
         <h3  class="page-header">Pretty URL</h3>
         <p>If you are creating a short url site, this function will come in handy to only allow url acceptable characters for your short url </p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.PrettyURL(FieldElementID); 

//Example 1
js.PrettyURL( $(".ShortURL") );

//Example 2
js.PrettyURL( $("#ShortURL") );
 
</pre> 
         <!--[URL - End]-->

         <a class="btn btn-primary btn_PrettyURL" role="button" data-toggle="collapse" href="#Collapse_PrettyURL" aria-expanded="false" aria-controls="Collapse_PrettyURL" >Example</a>   
         
         <div class="collapse" id="Collapse_PrettyURL">
            <br>  
            <p>Click in the field below and type in the url you would like</p>
            <br>
            <div class="form-group form-inline">
               http://awesomefunctions.com/
               <input type="text"class="form-control PrettyURL" value="" placeholder="awesome-functions">
            </div>
            
            <script>

            $(document).ready(function()
            {
               js.PrettyURL( $(".PrettyURL") ); 
            })
            </script>
 
         </div>




         <!--[URLEncode - Start]-->
         <span class="ScrollTo_URLEncode"  id="URLEncode" ></span>
         <h3  class="page-header">URL Encode</h3>
         <p>If you need to save a URL, you should be encoding it because some characters have a special meaning according to the 
         <a href="http://www.blooberry.com/indexdot/html/topics/urlencoding.htm"> URL specification</a>. 
         some characters are not allowed and some characters are not representable in all character sets.</p>
         <p>This function easily allow you to do that</p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.URLEncode(URL); 

//Example 1
js.URLEncode('http://www.awesomefunctions.com')

//Out put will be
http%3A%2F%2Fwww.awesomefunctions.com


//Example 2
js.URLEncode('http://abc.com/my page.html?name=bob&foo=bar#');

//Out put will be
http%3A%2F%2Fabc.com%2Fmy%20page.html%3Fname%3Dbob%26foo%3Dbar%23

 
</pre> 
         <!--[URLEncode - End]-->


         <!--[URLDecode - Start]-->
         <span class="ScrollTo_URLDecode"  id="URLDecode" ></span>
         <h3  class="page-header">URL Decode</h3>
         <p>This function easily allows you decode your encoded url</p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.URLDecode(URL); 

//Example 1
js.URLDecode('http%3A%2F%2Fwww.awesomefunctions.com')
 
//Out put will be
http://www.awesomefunctions.com


//Example 2
js.URLDecode('http%3A%2F%2Fabc.com%2Fmy%20page.html%3Fname%3Dbob%26foo%3Dbar%23');

//Out put will be
http://abc.com/my page.html?name=bob&foo=bar#

</pre> 
         <!--[URLDecode - End]-->


         <!--[GetUserRef - Start]-->
         <span class="ScrollTo_GetUserRef"  id="GetUserRef" ></span>
         <h3  class="page-header">Get User Referrer</h3>
         <p>One of the useful information is to know where are your users coming from. With this function you can easily find that out</p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.GetUserRef(); 

</pre> 
         <p>Note:</p>
         <p> - If a page is access directly, return will be "direct". Otherwise, it will return the url. </p>     
         <br><br>
         <p class="show_user_ref"></p>
         <script type="text/javascript">

         $(document).ready(function()
         {
            var msg = 'You came from: <b>'+ js.GetUserRef() + '<b>';
            $('.show_user_ref').html(msg);

            //console.log(ls.Get("GetUserRef"))
         })
         </script>

         <!--[GetUserRef - End]-->



			
			<!--[TableToJSON - Start]-->
			<span class="ScrollTo_TableToJSON"  id="TableToJSON" ></span>
			<h3  class="page-header">Table To JSON </h3>
			<p>With this function you can easily turn any standard html table in to json array</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax  
js.TableToJSON (TableElementID) 

//Method 1 
var data = js.TableToJSON($('#mdata') );
console.log("Data Arrray ", data)

//Method 2 
var data = js.TableToJSON($('.mdata') );
console.log("Data Arrray ", data)
 
</pre> 

			<br> 
			<a class="btn btn-primary btn_TableToJSON" role="button" data-toggle="collapse" href="#Collapse_TableToJSON" aria-expanded="false" aria-controls="Collapse_TableToJSON" >Example</a>	
			
			<div class="collapse" id="Collapse_TableToJSON">
				<br>	
				<b>Look at the console log for json array	</b>
				<br>
				<p>Below is the html table</p>
 
				<div style="display:none;" class="TableJsonCounter"></div>
				<table id="mdata" class="table   table-hover">				
					<thead>
						<tr>
							<th scope="col">Item</th>
							<th scope="col">Availability</th>
							<th scope="col">Qty</th>
							<th scope="col">Price</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Don&#8217;t Make Me Think by Steve Krug</td>
							<td>In Stock</td>
							<td>1</td>
							<td>$30.02</td>
						</tr>
						<tr>
							<td>A Project Guide to UX Design by Russ Unger &#38; Carolyn Chandler</td>
							<td>In Stock</td>
							<td>2</td>
							<td>$52.94 ($26.47 &#215; 2)</td>
						</tr>
						<tr>
							<td>Introducing HTML5 by Bruce Lawson &#38; Remy Sharp</td>
							<td>Out of Stock</td>
							<td>1</td>
							<td>$22.23</td>
						</tr>
						<tr>
							<td>Bulletproof Web Design by Dan Cederholm</td>
							<td>In Stock</td>
							<td>1</td>
							<td>$30.17</td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td>Subtotal</td>
							<td></td>
							<td></td>
							<td>$135.36</td>
						</tr>
						<tr>
							<td>Tax</td>
							<td></td>
							<td></td>
							<td>$13.54</td>
						</tr>
						<tr>
							<td>Total</td>
							<td></td>
							<td></td>
							<td>$148.90</td>
						</tr>
					</tfoot>
				</table>
 			</div>
			<!--[TableToJSON - End]-->
			
			<!--[DateDiff - Start]-->
			<span class="ScrollTo_DateDiff"  id="DateDiff" ></span>
			<h3  class="page-header">Date Diff</h3>
			<p>During your web programming, there will come a time when you want to know difference between 2 dates in terms of:  Years, months, weeks, days, hours, minutes and seconds</p>
			<p>This function makes it easier for you to find the difference between two dates	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax  
js.DateDiff (interval, date1, date2 ) 

//Note: interval
yr = years

month = months

wk = week

day = day

hr = hours

min = minutes

sec = seconds
 

//Method 1 
js.DateDiff ("yr", "8/1/2015","8/15/2016" ) ; //output:1

//Method 2 
js.DateDiff ("month", "6/1/2016","8/15/2016" ) ; //output: 2

//Method 3
js.DateDiff ("wk", "6/1/2016","8/15/2016" ) ; //output: 10

//Method 4
js.DateDiff ("day", "6/1/2016","8/15/2016" ) ; //output: 75

//Method 5
js.DateDiff ("hr", "8/23/2016","8/24/2016" ); //output: 24

//Method 6
js.DateDiff ("min", "8/23/2016 11:00 pm","8/24/2016 02:00 am" ); //output: 180
 
//Method 7
js.DateDiff ("sec", "8/24/2016 2:00:30 pm","8/24/2016 02:01 pm" ); //output: 30
  
 
</pre> 
 
			<!--[DateDiff - End]-->
			
			
			<!--[EnterKey - Start]-->
			<span class="ScrollTo_EnterKey"  id="EnterKey" ></span>
			<h3  class="page-header">Enter Key</h3>
			<p>If you like to detect whether your users have pressed "Enter Key" or not while being in a input field, this function makes it easy for you to detect that.</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax  
js.EnterKey (ElementID,callback)

//Method 1 
js.EnterKey ($(".UserEmail"), function (e)
{
  //prevent the page from reloading 
  e.preventDefault();
	
  //Call the submit process
  $(".Btn_UserForm").click();
	
})

//Method 2
js.EnterKey ($("#UserEmail"), function (e)
{
  //prevent the page from reloading 
  e.preventDefault();
	
  //Call the submit process
  $(".Btn_UserForm").click();
})


 
</pre> 
			<a class="btn btn-primary btn_EnterKey" role="button" data-toggle="collapse" href="#Collapse_EnterKey" aria-expanded="false" aria-controls="Collapse_EnterKey" >Example</a>	
			
			<div class="collapse" id="Collapse_EnterKey">
				<br>	
				<p>Click in the field below and pressed the enter key and see console.log() for result</p>
				<br>
				<div class="form-group form-inline">
					<input type="text"class="form-control tmk" value="" placeholder="click here">
				</div>
				
				<script>

            $(document).ready(function()
            {
   				js.EnterKey($('.tmk'),function (e) 
   				{
   					//prevent the page from reloading 
   					e.preventDefault();
   					//Call the submit process
   					console.log('enter keypressed');
   				}) 
            }) 
				</script>
 
			</div>

	
			<!--[EnterKey - End]-->


			<!--[PrintThis - Start]-->
			<span class="ScrollTo_PrintThis"  id="PrintThis" ></span>
			<h3  class="page-header">Print This</h3>
			<p  >If you ever wanted to allow your users to print only part of the page, this function can easily let you do that.</p>

			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax  
js.PrintThis (ElementContent)

//Method 1 
js.PrintThis ($(".UserEmail").html() );

//Method 2
js.PrintThis ($("#UserEmail").html() ); 

 
</pre> 
			<a class="btn btn-primary " role="button" data-toggle="collapse" href="#Collapse_PrintThis" aria-expanded="false" aria-controls="Collapse_PrintThis" >Example</a>	
			
			<div class="collapse" id="Collapse_PrintThis">
				<br>	
				<p class="PrintThisContent">When you click on the button below, it will only print this line and ignore the rest of the page content</p>
				<br>
				<div class="btn btn-success btn_PrintThis">Print This	</div>
				
				<script>

            $(document).ready(function()
            {
   				$(document).on('click', '.btn_PrintThis', function(event) 
   				{
   					 event.preventDefault();

   					var Content = $('.PrintThisContent').html();
   					js.PrintThis (Content );   
   					
   				})
            })
				</script>
 
			</div>
			<!--[PrintThis - End]-->


         <!--[LimitChar - Start]-->
         <span class="ScrollTo_LimitChar"  id="LimitChar" ></span>
         <h3  class="page-header">Limit Characters</h3>
         <p>If you have a string that contains 100 characters but you only want to show first 10 characters, this function can easily let you do that.</p>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
 js.LimitChar(str, len) 

//Call it like this
js.LimitChar('awesome functions', 8); 

//Output will be: awesome
 
</pre> 
         <!--[LimitChar - End]-->


         <!--[Size - Start]-->
         <span class="ScrollTo_Size"  id="Size" ></span>
         <h3  class="page-header">Size</h3>
         <p>Easily find out the length of a string, arrays, or objects </p>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
 js.Size(str) 

//Method 1 
js.Size('awesome functions'); //Output will be=> 17

//Method 2 
js.Size([1, 2, 3]); //Output will be => 3
 
//Method 3
js.Size({ 'a': 1, 'b': 2 }); //Output will be => 2

 
</pre> 
         <!--[Size - End]-->




         <!--[Escape - Start]-->
         <span class="ScrollTo_Escape"  id="Escape" ></span>
         <h3  class="page-header">Escape</h3>
         <p>Easily convert the characters "&", "<", ">", ' " ', " ' " and along with others to their corresponding HTML entities. </p>
         <p>You should run your data through this function to ensure that no sql injections are taking place before going throug php and mysql</p>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.Escape(str) 

//Call it like this
js.Escape('awesome functions, 123 & code with mark'); 

//Output will be=> awesome functions, 123 &nbsp;&amp;amp;&nbsp; code with mark


</pre> 
         <!--[Escape - End]-->


         <!--[UnEscape - Start]-->
         <span class="ScrollTo_UnEscape"  id="UnEscape" ></span>
         <h3  class="page-header">UnEscape</h3>
         <p>You should run your data through this function to reverse the Escape process </p>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.UnEscape(str) 

//Call it like this
js.UnEscape(' awesome functions, 123 &nbsp;&amp;amp;&nbsp; code with mark'); 

//Output will be=> awesome functions, 123 & code with mark
 
</pre> 
         <!--[UnEscape - End]-->


         <!--[MD5 - Start]-->
         <span class="ScrollTo_MD5"  id="MD5" ></span>
         <h3  class="page-header">MD5</h3>
         <p>You can easily create a MD5 hash with this function.</p>
         <p>This takes a 2 parameters:</p>
         <ol>
            <li>String: a string you would like to hash. If a string is not provided, an auto hash will be generated.</li>
            <li>Lenght: number of character you would like the hash to return. Max is 32 characters</li>
         </ol>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  
js.MD5(str, len) 

str = string you would like to hash.

//Method 1
js.MD5(); //Output=> c7e2a7f19808b127451330df86352e45 

//Method 2
js.MD5('',5); //Output=> de483

//Method 3
js.MD5('awesome functions'); //Output=> a8c505d8e700045701780e2e0c61c7f7

//Method 4
js.MD5('code with mark',5); //Output=> a8c50



 
</pre> 
         <!--[MD5 - End]-->

         



        

         
      <!--[Encode - Start]-->
         <span class="ScrollTo_Encode"  id="Encode" ></span>
         <h3  class="page-header" >Encode </h3>
         <p>This will Encode your string </p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.Encode (StringVal)

js.Encode("codewithmark")
 
//--->Out put will
Y29kZXdpdGhtYXJr
</pre>
         <!--[Encode - End]-->   

         <!--[Decode - Start]-->
         <span class="ScrollTo_Encode"  id="Decode" ></span>
         <h3  class="page-header" >Decode </h3>
         <p>This will Decode your string </p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.Decode(StringVal)

js.Decode("Y29kZXdpdGhtYXJr")
 
//--->Out put will
codewithmark
</pre> 
         <p><em>Note: js.Encode() and js.Decode() will only work in javascript unlike the <a href="http://awesomefunctions.com/php#Encode">PHP version.</a>&nbsp;Meaning that you can&#39;t send js.Encode() value to php and then decode in php. It will not work.&nbsp;</em></p>
         <!--[Decode - End]-->


         
      <!--[Ajax - Start]-->
         <span class="ScrollTo_Ajax"  id="Ajax" ></span>
         <h3  class="page-header" >Ajax </h3>
         <p>This function easily allows you to send different types of json ajax requests to your server.  </p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.Ajax(CallType,AjaxURL,DataString)


//Example

var CallType   = 'GET' //--->Other options: GET/POST/DELETE/PUT
var AjaxURL    = 'http://awesomefunctions.com';
var DataString = {user:'codewithmark',email:'help@awesomefunctions.com'};


var ajax = js.Ajax(CallType,AjaxURL,DataString)

//error
ajax.fail(function(xhr, ajaxOptions, thrownError)  
{ 
  //do your error handling here
   console.log(thrownError);
   console.log(xhr);        
});

//success
ajax.done(function(data) 
{ 
  //do your success data processing here
  console.log(data)
}); 
 
</pre>
         <!--[Ajax - End]-->  



      <!--[CreateTable - Start]-->
         <span class="ScrollTo_Ajax"  id="CreateTable" ></span>
         <h3  class="page-header" >Create Table </h3>
         <p>This function easily allows create html tables with your json object array data  </p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.CreateTable(DataArr,Columns) 


//Example

var DataArr =
[
   {user_name:'awesomefunctions',site:'http://awesomefunctions.com'},
   {user_name:'codewithmark',site:'http://codewithmark.com'},
   {user_name:'google',site:'http://google.com'},
]

//Method 1 - No custom columns

//Will create and return table data
var tbl = js.CreateTable(DataArr);

//Out put table
$('.mytablediv').html(tbl);


//Method 2 - With custom columns

//Will create and return table data
var Columns = ["Names", "Sites"];

var tbl = js.CreateTable(DataArr,Columns);

//Out put table 
$('.mytablediv').html(tbl);
 
</pre>

         <a class="btn btn-primary " role="button" data-toggle="collapse" href="#Collapse_CreateTable" aria-expanded="false" aria-controls="Collapse_CreateTable" >Example</a> 
         
         <div class="collapse" id="Collapse_CreateTable">
            <br>  
            <script>
            $(document).ready(function()
            {
               var DataArr =
               [
                  {user_name:'awesomefunctions',site:'http://awesomefunctions.com'},
                  {user_name:'codewithmark',site:'http://codewithmark.com'},
                  {user_name:'google',site:'http://google.com'},
               ]

               $('.myTableNoColumns').html( js.CreateTable(DataArr) ) ;
               $('.myTableWithColumns').html( js.CreateTable(DataArr,["Names", "Sites"]) );
            });
               

            </script>

          
            <b>No Custom Columns</b>
            <div class="myTableNoColumns"></div>
            <br> 

            <b>With Custom Columns</b>
            <div class="myTableWithColumns"></div>
            <br><br>
 
         </div>
      

         <!--[CreateTable - End]-->  



      <!--[IsMobile - Start]-->
         <span class="ScrollTo_IsMobile"  id="IsMobile" ></span>
         <h3  class="page-header" >Is Mobile </h3>
         <p>This will tell you if your visitor is accessing your page from mobile device </p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.IsMobile()

//just call the function
if(js.IsMobile())
{
 console.log('accessing from mobile')
}
else
{
 console.log('accessing from desktop')  
}

</pre>
         <!--[IsMobile - End]-->   



         <!--[IncludeOnce - Start]-->
         <span class="ScrollTo_IncludeOnce"  id="IncludeOnce" ></span>
         <h3  class="page-header" >Include Once</h3>
         <p>If you need to include a js or css file after the page has been loaded, this function will include it only once. Like php function: include_once</p>
         <em>Note: File has to be loaded in the DOM before you can access and use it </em>
         <br>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.IncludeOnce('your file path')

//just call the function

//include css
js.IncludeOnce('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css');

//include js
js.IncludeOnce('https://awesomefunctions.com/cdn/awesome-functions.min.js');

</pre>
         <!--[IncludeOnce - End]-->   


         <!--[IsIncluded - Start]-->
         <span class="ScrollTo_IsIncluded"  id="IsIncluded" ></span>
         <h3  class="page-header" >Is Included</h3>
         <p>Use this function to check if the file is included.</p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.IsIncluded('your file path')

//just call the function

//include css
js.IsIncluded('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css');

//include js
js.IsIncluded('https://awesomefunctions.com/cdn/awesome-functions.min.js');

</pre>
         <!--[IsIncluded - End]-->   


         <!--[RemoveOnce - Start]-->
         <span class="ScrollTo_RemoveOnce"  id="RemoveOnce" ></span>
         <h3  class="page-header" >Remove Once</h3>
         <p>Use this function to remove to a file</p>
         <p></p>
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax 
js.RemoveOnce('your file path')

//just call the function

//include css
js.RemoveOnce('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css');

//include js
js.RemoveOnce('https://awesomefunctions.com/cdn/awesome-functions.min.js');

</pre>
         <!--[IsIncluded - End]-->   

        
			
 
		 
		 <br> <br> <br>

		</div>
		
		<!--[Right Side Bar - Start]-->
		<div class="col-md-3  ">			
			<div  class="sidebar-nav-fixed pull-right affix" style="max-height:100vh; overflow: auto;">
			
   			<p class="lead text-center">Functions</p>
   			<div class="list-group small ">
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_SEO" href="#SEO">SEO</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Int" href="#Int">Int</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_AutoCode" href="#AutoCode">AutoCode</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Template" href="#Template">Template</a>

   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_ChangePageTitle" href="#ChangePageTitle">Change Page Title </a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_FormatDateTime" href="#FormatDateTime">Format Date/Time </a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetFutureDate" href="#GetFutureDate">Get Future Date </a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CharCount" href="#CharCount">Character Count </a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsOnline" href="#IsOnline">Is Online</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetFolderPath" href="#GetFolderPath">Get Folder Path</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetSiteURL" href="#GetSiteURL">Get Site URL</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CapitalizeFirstLetter" href="#CapitalizeFirstLetter">Capitalize First Letter</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetFileName" href="#GetFileName">Get File Name</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetFileExt" href="#GetFileExt">Get File Ext</a>
   				
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_URL" href="#URL">URL</a>	
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_PrettyURL" href="#PrettyURL">Pretty URL</a>  

               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_URLEncode" href="#URLEncode">URL Encode</a>  
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_URLDecode" href="#URLDecode">URL Decode</a>  
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_GetUserRef" href="#GetUserRef">Get User Referrer</a>  


   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_TableToJSON" href="#TableToJSON">Table To JSON</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_DateDiff" href="#DateDiff">Date Diff</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_EnterKey" href="#EnterKey">Enter Key</a>
   				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_PrintThis" href="#PrintThis">Print This</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LimitChar" href="#LimitChar">Limit Characters</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Size" href="#Size">Size</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Escape" href="#Escape">Escape</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_UnEscape" href="#UnEscape">UnEscape</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_MD5" href="#MD5">MD5 Hash</a>
               
               

               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Encode" href="#Encode">Encode</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Decode" href="#Decode">Decode</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Ajax" href="#Ajax">Ajax</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateTable" href="#CreateTable">Create Table</a>

               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsMobile" href="#IsMobile">Is Mobile</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsIncluded" href="#IsIncluded">Is Included</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IncludeOnce" href="#IncludeOnce">Include Once</a>
               <a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_RemoveOnce" href="#RemoveOnce">Remove Once</a>

   				
            <br><br>
            </div>
            <br><br>
			</div>
			
		</div>
		
		
		<!--[Right Side Bar - End]-->
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->

<?php include('footer.php') ?>
	
</body>

</html>