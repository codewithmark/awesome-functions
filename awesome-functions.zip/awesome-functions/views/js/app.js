
$(document).ready(function()
{
    //console.clear(); 
    $('[data-toggle="tooltip"]').tooltip();

    js.SEO();  
});

//--->ScrollToElement - Start

function ScrollToElement(objID)
{
 	$('html, body').animate({scrollTop: objID.offset().top-50}, 1000);
};

//Go to hash tag on page load
$(window).on('load',function()
{ 
	var d = js.URL('hash').replace("#", "ScrollTo_");
	//console.log(d)
	if(d)
	{
		ScrollToElement($("."+d+""));		
	}
	
});


$( document ).on( 'click', '.ScrollToElement1', function(e) 
{	
	//e.preventDefault();
	var ScrollObjID = $(this).attr('ScrollObjID');
	ScrollToElement($("."+ScrollObjID+""));
	//ScrollToElement($("."+ScrollObjID+""));
});

//Go to hash tag on click/change
$(window).on('hashchange',function()
{ 
	//var d = js.URL('hash').replace("#", "ScrollTo_");
	window.scrollTo(window.scrollX, window.scrollY - 60);
});
//--->ScrollToElement - End

function looks_like_html(source) 
{
        // <foo> - looks like html
        var trimmed = source.replace(/^[ \t\n\r]+/, '');
        return trimmed && (trimmed.substring(0, 1) === '<');
};

var escape = function(s)
{
    var tagsToReplace = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;'
    };
    return s.replace(/[&<>]/g, function(tag) {
        return tagsToReplace[tag] || tag;
    });
};

var PrettyCode_test  = function (look_up_tag) 
{
    var ele_tag = look_up_tag ? look_up_tag : 'pre'

    var ele = $(document).find(ele_tag)

    if(ele.length < 1)
    {
        return false
    }

    $('body').append('<textarea class="code_raw" style="display:none;"></textarea>')
    
    var temp_code = $(document).find('.code_raw')

    ele.each(function(i1, v1) 
    { 
        console.log(v1)
        
        var raw_code = $(this).html()

        temp_code.html(raw_code)

        var out_put =  temp_code.html()

        $(this).html(out_put)
    })
    temp_code.remove()

};
var PrettyCode = function () 
{
    /*
        this will load the code container from the page and add line numbers to it
    */
    var ele = $(document).find('pre')

    if(ele.length < 1)
    {
        return false
    }

    //console.log('ele ', ele.length)
    $('body').append('<textarea class="code_raw"></textarea>')
     var temp_code = $(document).find('.code_raw')
    ele.each(function(i1, v1) 
    { 
        var get_pre_container = $(this).closest('pre');
        var get_pre_container_class = get_pre_container.attr('class');        
        var raw_code = $(this).html();
        
        //var js_pretty =  
       
        temp_code.html(raw_code)

        console.log(temp_code)

        var d = looks_like_html(raw_code)
        var output
        if(d)
        {
            output = html_beautify(raw_code)    
            //output = js_beautify(get_code)    
        }
        else 
        {
            output = js_beautify(raw_code)  
        }           
        
        //var code_container = escape(output).split('\n');
        var code_container =   temp_code.html().split('\n');

        var js_pretty =  js_beautify(raw_code)

        var class_id  = Math.random().toString(36).substr(2, 5);

        var get_pre_container_class = 'language-javascript'
        var html = '';
        html+='<div class="table-responsive  "> ';
            html+= '<pre class="'+get_pre_container_class+' " style="background:none!important;">';
            html+='<table class="table table-hover table-condensed" >';
            $.each(code_container, function(i2, v2) 
            {
                html+=''
                +'<tr >'
                    //Line number 
                    +'<td style="border-right-width:3px;border-right-style: solid;border-right-color: rgb(108, 226, 108);">' + (i2 + 1) + '</td> '
                    //code
                    +'<td style="    border-top: 1px solid #f0f0f0;">'+v2 +'</td> '
                +'</tr>' ; 
               

            })          
            html+= '</table>';
            html+= '</pre>';     
        html+='</div>'; 

        var arr = 
        [   
            {tab_name:'Code', tab_content:html},
            {tab_name:'Raw Code', tab_content: '<pre class="'+get_pre_container_class+'" >'+temp_code.html()+'</pre>'}, 
        ]
        
        get_pre_container.html(temp_code.html())
        //get_pre_container.after( BS_Tabs(arr) );
        

        //remove the original container
        //get_pre_container.remove();


    });

    temp_code.remove()
};


var BS_Tabs = function (ObjArr)
{   
    /*
        Will create a Bootstrap tab screen

        //example tab data array
        var arr = [ 
            {tab_name:'tab 1', tab_content: "this is my tab 1 contain is"},
            {tab_name:'tab 2', tab_content: "this is my tab 2 "},
        ]
    */
    //Get object Arr
    var arr = ObjArr; 

    //--->get tab name - start
    var id  = Math.random().toString(36).substr(2, 5);
    var strTabName = '';
    strTabName +='<ul class="nav nav-tabs" role="tablist">';
    arr.forEach( function(element, index) 
    {
        //var tab_id =  (element.tab_name).replace(/[^\w]+/g, '-') 
        var tab_id =  (element.tab_name).replace(/[^\w]+/g, '-') +'-id-'+id
        var tab_name = element.tab_name
        if(index <1)
        {
            strTabName +='<li role="presentation" class="active"><a href="#'+tab_id+'"  role="tab" data-toggle="tab">'+tab_name+'</a></li>'
        }
        else
        {
            strTabName +='<li role="presentation"><a href="#'+tab_id+'"  role="tab" data-toggle="tab">'+tab_name+'</a></li>'
        }
         
    });
    strTabName +='</ul>';
    //--->get tab name - end

    //--->get tab content - start
    var strTabContent = '';
    strTabContent +='<div class="tab-content" style="padding:10px;">';
    arr.forEach( function(element, index) 
    {
        var tab_id = (element.tab_name).replace(/[^\w]+/g, '-') +'-id-'+id
        var tab_content = element.tab_content
        if(index <1)
        {
            strTabContent +='<div role="tabpanel" class="tab-pane active '+tab_id+'" id="'+tab_id+'">'+tab_content+'</div>'
        }
        else
        {
            strTabContent +='<div role="tabpanel" class="tab-pane '+tab_id+'" id="'+tab_id+'">'+tab_content+'</div>'
        }
         
    });
    strTabContent +=' </div>';
    //--->get tab content - end

    var strTabDiv = ''
    +'<div class="panel panel-default"  >'    
        + strTabName
        + strTabContent    
    + '</div>'
    //console.log(strTabDiv)
    return strTabDiv;
    
};