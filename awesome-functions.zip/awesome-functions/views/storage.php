<?php
//include_once ('_inc/_config.php');
?>
<!DOCTYPE html>
<html>
<head>

	<title>Storage Functions - Awesome Function</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Sometimes web pages are more than just static sources of information; sometimes they want to interact with and know something about their useres. In order to do this, websites need to store data locally on the client-side. ">
 
	
<?php include('header.php') ?>
 
	<script type="text/javascript"> 



	$(document).ready(function()
	{
		//console.clear(); 
		$('[data-toggle="tooltip"]').tooltip();
		
	});
	</script>
	
	
</head>
 
<body >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row">
 
		
		<!--[Body Container - Start]-->
		<div class="col-md-9">
			
			<!--[Cookie Description - Start]-->
			<h1 class="text-center">Storage</h1>
			<p  class="text-center">These functions have dependency on jQuery</p> 
			<br>	<br>
 
			<p>Sometimes web pages are more than just static sources of information; sometimes they want to interact with and know something about their users. In order to do this, websites need to store data locally on the client-side.</p>
			<p>There are two simple ways for you to store data: 
				<strong> <a href="#Cookies" class="ScrollToElement" ScrollObjID="ScrollTo_Cookies">Cookies</a> </strong>
				and 
				<strong> <a href="#LocalStorage" class="ScrollToElement" ScrollObjID="ScrollTo_LocalStorage">Local Storage</a> </strong>
			 </p>
			<!--[Cookie Description - End]-->
			
			<!--[Bootstrap Panel DIV - End]-->
			
			
			<div class="panel panel-info">
			
			<!--[Local Storage Description - Start]-->
				<span class="ScrollTo_Cookies" id="Cookies"></span>
			<div class=" panel-heading text-center" ><h2>Cookies</h2></div>
	
			<!--[Bootstrap Panel Body Content - Start]-->
			<div class="panel-body">
			
			<!--[Cookies - Start]-->	
	 
			<p>If you would like&nbsp;to store something less than 4KB of data, then cookies will do the job for you.</p>
			<p>Below are the awesome cookie functions for you to store simple data</p>

			<!--[Add - Start]-->
			<span class="ScrollTo_CAdd" id="CAdd"></span>
			<h3  class="page-header">Add</h3>
			<p>Simplest way to add a cookie is as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax
c.Add(cookiename,value,daysexpiredin );

//Without days expired in
c.Add('codewithmark','I love Awesome Functions' );

//With days expired in
c.Add('codewithmark','I love Awesome Functions',2 );
</pre>
			<p>Note if daysexpiredin is not provided, then it will default to 1 day</p>
			<!--[Add - End]-->

			<!--[Get - Start]-->
			<span class="ScrollTo_CGet" id="CGet"></span>
			<h3  class="page-header">Get</h3>
			<p>Simplest way to get a cookie is as follow:	</p>
			<b>Usage</b>			 
	<pre class="bg-success ">
//Syntax
c.Get(cookiename);

c.Get('codewithmark' ); //out put ---> I love Awesome Functions
</pre>
			<!--[Get - End]-->


			<!--[Add Object Array - Start]-->
			<span class="ScrollTo_CAddObjArr" id="CAddObjArr" ></span>
			<h3  class="page-header">Add Object Array</h3>
			<p>If you want to add more than just a string of data, you can use object array method as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//syntax
c.AddObjArr(cookiename,ObjArr);

//Method 1
var ObjArr = {test1: 'test1',test2:'test2'};
c.AddObjArr('awesomefunctions1',ObjArr);

//Method 2
var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Chad', 'age' : 3 },
]
c.AddObjArr('awesomefunctions2',people);
</pre>
			<!--[Add Object Array - End]-->

			<!--[Get Object Array - Start]-->
			<span class="ScrollTo_CGetObjArr" id="CGetObjArr" ></span>
			<h3  class="page-header">Get Object Array</h3>
			<p>Simplest way to get object array a cookie is as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax
c.GetObjArr(cookiename);

//Example
c.GetObjArr('awesomefunctions1') 

c.GetObjArr('awesomefunctions2') 
</pre>
			<!--[Get Object Array - Start]-->

	
			<!--[Delete - Start]-->
			<span class="ScrollTo_CDelete" id="CDelete"></span>
			<h3  class="page-header">Delete</h3>
			<p>Deleting a cookie is easy	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax
c.Delete(cookiename);

//Example
c.Delete('codewithmark');
</pre>
			<!--[Delete - End]-->
			</div>
			<!--[Bootstrap Panel Body Content - End]-->
		</div>	
		<!--[Bootstrap Panel DIV - End]-->
<!--[Cookies - End]-->

<hr>
<!--[Local Storage - Start]-->	

    <div class="panel panel-info">
			<!--[Local Storage Description - Start]-->

			<!--[Bootstrap Panel DIV - End]-->
			<span class="ScrollTo_LocalStorage" id="LocalStorage"></span>
			<div class=" panel-heading text-center"><h2  >Local Storage</h2></div>
			
			<!--[Bootstrap Panel Body Content - Start]-->
			<div class="panel-body">

			<p><strong>What is&nbsp;Local Storage?</strong></p>

			<p>It allows you to add data(string, objects and json arrays) on your client&#39;s computer. The data stored in localStorage has no expiration time.</p>

			<p>You can open a new tab/window or close the browser completely and come back local storage data will be there.</p> 
	 
			<small>Note: This only allow you to add up to 5 MB of data</small>

			<!--[Local Storage Description - End]-->

			<!--[Add - Start]-->
			<span class="ScrollTo_LSAdd" id="LSAdd"></span>
			<h3  class="page-header">Add</h3>
			<p>Easiest way to add a storage is as follow:</p>
			<b>Usage</b>			 
<pre class="bg-success "> 
//Syntax for local storage
ls.Add(localstoragename,value);

 
ls.Add('codewithmark','I love Awesome Functions' ); 
</pre>
			<!--[Add - End]-->

			<!--[Get - Start]-->
			<span class="ScrollTo_LSGet" id="LSGet"></span>
			<h3  class="page-header">Get</h3>
			<p>Simplest way to get a  storage is as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.Get(localstoragename);

ls.Get('codewithmark' ); //out put ---> I love Awesome Functions
</pre>
			<!--[Get - End]-->


			<!--[Add Object - Start]-->
			<span class="ScrollTo_LSAddObj" id="LSAddObj"></span>
			<h3  class="page-header">Add Object</h3>
			<p>If you want to add multiple strings, you can use object method to store stuff as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.AddObj(localstoragename,ObjArr);
 
var ObjArr = {username: 'test1',useremail:'test@gmail.com', useraccesstype:"level1"};
ls.AddObj('awesomefunctions',ObjArr);
</pre>
			<p>Note: This shoule be used for a single array only with multiple objects. If you to add multiple arrays with objects, use "Add Array" method (see below) </p> 
			 
			<!--[Add Object - End]-->

			<!--[Get Object - Start]-->
			<span class="ScrollTo_LSGetObj" id="LSGetObj"></span>
			<h3  class="page-header">Get Object</h3>
			<p>Simplest way to get a storage object is as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success "> 
//Syntax for local storage
ls.GetObj(localstoragename);

ls.GetObj('awesomefunctions')  
</pre>
			<!--[Get Object - Start]-->



			<!--[Update Object - Start]-->
			<span class="ScrollTo_LSUpdateObj" id="LSUpdateObj"></span>
			<h3  class="page-header">Update Object</h3>
			<p>To update your objects</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success "> 
//Syntax for local storage
ls.UpdateObj (localstoragename,FieldObjArrToUpdatValue,WhereObjArr) 

var people =  { 'name' : 'Bella', 'age' : 3 ,'age1' : 1 ,'code':'test' }

//Add data
ls.AddObj('awesomefunctions',people); 

var FieldObjArrToUpdatValue = { 'code':'my name is', 'age1':'mark 007'}

var WhereObjArr = { 'name' : 'Bella', 'age' : 3   }

//Update value
ls.UpdateObj ('awesomefunctions',FieldObjArrToUpdatValue,WhereObjArr) 


//--->New data will be
{ 'name' : 'Bella', 'age' : 3 ,'code':'my name is', 'age1':'mark 007'}

</pre> 
			<!--[Update Object  - End]-->






			<!--[Add Array - Start]-->
			<span class="ScrollTo_LSAddArr" id="LSAddArr"></span>
			<h3  class="page-header">Add Array</h3>
			<p>If you want to add multiple object arrays one at time, you can use array method as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.AddArr(localstoragename,ObjArr);
 
var people = { 'name' : 'Abel', 'age' : 1 };
ls.AddArr('awesomefunctions',people);

var people1 = { 'name' : 'Chad', 'age' : 4 };
ls.AddArr('awesomefunctions',people1); 
</pre>
			<!--[Add Array - End]-->

			<!--[Add Temp Array - Start]-->
			<span class="ScrollTo_LSAddTempArr" id="LSAddTempArr"></span>
			<h3  class="page-header">Add Temp Array</h3>
			<p>This works similar to Add Array the only difference is that this doesn't append to your old data.</p>
			<p>When you add an array data with this function, this will delete the old array data first and then add the new array data in the storage.</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.AddTempArr(localstoragename,ObjArr);
 
var people = { 'name' : 'Abel', 'age' : 1 };
ls.AddTempArr('awesomefunctions',people);

var people1 = { 'name' : 'Chad', 'age' : 4 };
ls.AddTempArr('awesomefunctions',people1); 
</pre>
			<!--[Add Array - End]-->


			<!--[Add Bulk Arrays - Start]-->
			<span class="ScrollTo_LSAddBulkObj"  id="LSAddBulkObj"></span>
			<h3  class="page-header">Add Bulk Array</h3>
			<p>If you want to add multiple object arrays at once, you can do so as follow:	</p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.AddBulkArr(localstoragename,Arr);
 
var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]

ls.AddBulkArr('awesomefunctions',people);
</pre>
			<!--[Add Array - End]-->

			<!--[Add Bulk Arrays - Start]-->
			<span class="ScrollTo_LSAddTempBulkArr"  id="LSAddTempBulkArr"></span>
			<h3  class="page-header">Add Temp Bulk Array</h3>
			<p>This works similar toAdd Bulk Array the only difference is that this doesn't append to your old data.</p>
			<p>When you add an array data with this function, this will delete the old array data first and then add the new array data in the storage.</p>
			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.AddTempBulkArr(localstoragename,Arr);
 
var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]

ls.AddTempBulkArr('awesomefunctions',people);
</pre>
			<!--[Add Array - End]-->

			<!--[Get Array - Start]-->
			<span class="ScrollTo_LSGetArr" id="LSGetArr" ></span>
			<h3  class="page-header">Get Array</h3>
			<p>If you just want to filter for a search criteria (Let's assume you want to get all of object arrays where name equal "Bella" and age equal "2") in your object array, you can do it as follow:</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.GetArr(localstoragename,WhereValueEquals)

var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]
//Add
ls.AddBulkArr('awesomefunctions',people);


//lookup and get
var WhereValueEquals = {name:'Bella',age:2}

var data = ls.GetArr('awesomefunctions',WhereValueEquals)
 
console.log(data)

//Out put will be:
{ 'name' : 'Bella', 'age' : 2 }
   
</pre>
			<!--[Get Array - End]-->


			<!--[Get All Array - Start]-->
			<span class="ScrollTo_LSGetAllArr" id="LSGetAllArr" ></span>
			<h3  class="page-header">Get All Arrays</h3>
			<p>If you just want to get all of the object arrays, you can do it as follow:</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.GetAllArr(localstoragename);


//Add array objects
var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]

ls.AddBulkArr('awesomefunctions',people);


//Get all of them back
var d = ls.GetAllArr('awesomefunctions');

console.log(d);
//outputput will be:
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]  
   
</pre>
 
			<!--[Get All Array - End]-->

			<!--[Get Array Count - Start]-->
			<span class="ScrollTo_LSGetArrCount" id="LSGetArrCount"></span>
			<h3  class="page-header">Get Array Count</h3>
			<p>If you just want to get total number of object arrays, you can do it as follow:</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.CountArr(localstoragename)

var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 3 },
 { 'name' : 'Chad', 'age' : 4 },
]

ls.AddBulkArr('awesomefunctions',people);

ls.CountArr('awesomefunctions') //--->Out put will be 4
</pre>
 
			<!--[Get Array Count - End]-->



			<!--[Update Array - Start]-->
			<span class="ScrollTo_LSUpdateArr" id="LSUpdateArr"></span>
			<h3  class="page-header">Update Array</h3>
			<p>To update your object array:</p>
			<p></p>
			<b>Example 1</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.UpdateArr (localstoragename,FieldObjArrToUpdatValue,WhereObjArr) 

var people = 
[
 { name : 'Abel', age : 1 },
 { name : 'Bella', age : 2 },
 { name : 'Bella', age : 3 },
 { name : 'Chad', age : 4 },
]

//Add data
ls.AddBulkArr('awesomefunctions',people); 

var FieldObjArrToUpdatValue = { 'age' : 'NewBella'}

var WhereObjArr = { 'name' : 'Bella'}

//Update value
ls.UpdateArr ('awesomefunctions',FieldObjArrToUpdatValue,WhereObjArr) 


//--->New data will be
[
 { name : 'Abel',  age : 1 },
 { name : 'Bella', age : 'NewBella' },
 { name : 'Bella', age : 'NewBella' },
 { name : 'Chad',  age : 4 },
]
</pre>
				<b>Example 2</b>			 
<pre class="bg-success ">
//Syntax for local storage 
ls.UpdateArr (localstoragename,FieldObjArrToUpdatValue,WhereObjArr) 

var people = 
[
 { name : 'Abel',  age : 1, food: "Pizza", level : 1 },
 { name : 'Bella', age : 2, food: "Chocolate", level : 2 },
 { name : 'Bella', age : 2, food: "Chocolate", level : 22 },
 { name : 'Bella', age : 3, food: "Ice Cream", level : 3 },
 { name : 'Chad',  age : 4, food: "Bacon", level : 4 },
]

//Add data
ls.AddBulkArr('awesomefunctions',people);


var UpdatValue = { age : 'NewBella'}

var Where = { name : 'Bella', food : 'Chocolate',  level : 22}

//Update value
ls.UpdateArr ('awesomefunctions',UpdatValue,Where) 


//--->New data will be
[
 { name : 'Abel',  age : 1, food: "Pizza", level : 1 },
 { name : 'Bella', age : 2, food: "Chocolate", level : 2 },
 { name : 'Bella', age : 'NewBella', food: "Chocolate", level : 22 },
 { name : 'Bella', age : 3, food: "Ice Cream", level : 3 },
 { name : 'Chad',  age : 4, food: "Bacon", level : 4 },
]
</pre>
			<b>Example 3</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.UpdateArr (localstoragename,FieldObjArrToUpdatValue,WhereObjArr) 

var people = 
[
 { name : 'Abel',  age : 1, food: "Pizza", level : 1 },
 { name : 'Bella', age : 2, food: "Chocolate", level : 2 },
 { name : 'Bella', age : 2, food: "Chocolate", level : 22 },
 { name : 'Bella', age : 3, food: "Ice Cream", level : 3 },
 { name : 'Chad',  age : 4, food: "Bacon", level : 4 },
]

//Add data
ls.AddBulkArr('awesomefunctions',people);


var UpdatValue = { age : 'NewBella',food : 'Chickfila',level : 0}

var Where = { name : 'Bella' }

//Update value
ls.UpdateArr ('awesomefunctions',UpdatValue,Where) 


//--->New data will be
[
 { name : 'Abel',  age : 1, food: "Pizza", level : 1 },
 { name : 'Bella', age : 'NewBella',food : 'Chickfila',level : 0 },
 { name : 'Bella', age : 'NewBella',food : 'Chickfila',level : 0 },
 { name : 'Bella', age : 'NewBella',food : 'Chickfila',level : 0 },
 { name : 'Chad',  age : 4, food: "Bacon", level : 4 },
]
</pre>	
			<!--[Update Array  - End]-->



			<!--[Delete Array - Start]-->
			<span class="ScrollTo_LSDeleteArr" id="LSDeleteArr"></span>
			<h3  class="page-header">Delete Array</h3>
			<p>To delete your object array(s):</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.DeleteArr (localstoragename,WhereValueEquals)

var people = 
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Bella', 'age' : 2 },
 { 'name' : 'Chad', 'age' : 4 },
]

//Add data
ls.AddBulkArr('awesomefunctions',people);
 

//Delete arrays 
var WhereValueEquals = {name:'Bella',age:2}

var data = ls.DeleteArr ('awesomefunctions',WhereValueEquals)
 
 
//Get new data
var data = ls.GetAllArr('awesomefunctions');

console.log(data)

//--->New data will be
[
 { 'name' : 'Abel', 'age' : 1 },
 { 'name' : 'Chad', 'age' : 4 },
]

</pre>
			<!--[Delete Array  - End]-->

			<!--[Exist - Start]-->
			<span class="ScrollTo_LSExist" id="LSExist" ></span>
			<h3  class="page-header">Exist</h3>
			<p>Check to see if your storage exist </p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage 
ls.Exist (localstoragename) 

ls.Exist ('awesomefunctions')

//--->return True if it exist...else false
</pre>
			<!--[Exist - End]-->

			<!--[Empty - Start]-->
			<span class="ScrollTo_LSEmpty" id="LSEmpty"></span>
			<h3  class="page-header">Empty</h3>
			<p>You can easily Empty your storage</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.Empty (localstoragename) 

ls.Empty ('awesomefunctions') 

//--->No out put will return 
</pre>
			<!--[Exist - End]-->


			<!--[Delete - Start]-->
			<span class="ScrollTo_LSDelete" id="LSDelete" ></span>
			<h3  class="page-header">Delete</h3>
			<p>If you would completely like to delete your storage, you can easily do like this:</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
 //Syntax for local storage
ls.Delete(localstoragename) 

ls.Delete('awesomefunctions') 

//--->No out put will return 
</pre>
			<!--[Delete - End]-->


			<!--[Delete - Start]-->
			<span class="ScrollTo_LSDeleteAll" id="LSDeleteAll" ></span>
			<h3  class="page-header">Delete All Storages</h3>
			<p>If you would  delete all your storages, you can easily do like this:</p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax for local storage
ls.DeleteAll() 

//--->No out put will return 
</pre>
			<!--[Delete - End]-->

			</div>
			<!--[Bootstrap Panel Body Content - End]-->
		</div>
		<!--[Bootstrap Panel DIV - End]-->

<!--[Local Storage - End]-->	
		</div> 
		
		<!--[Body Container - End]-->
		
		
		
		<!--[Right Side Bar - Start]-->
		<div class="col-md-3  ">			
			<div  class="sidebar-nav-fixed pull-right affix" style="max-height:100vh; overflow: auto;">
				
				<p class="lead text-center">Functions</p>
				<div class="list-group  small">
					<b><a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_Cookies" href="#Cookies">Cookies</a></b>
					<a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_CAdd" href="#CAdd">Add</a>
					<a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_CGet" href="#CGet">Get</a>

					<a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_CAddObjArr" href="#CAddObjArr">Add Object Array</a> 
					<a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_CGetObjArr" href="#CGetObjArr">Get Object Array</a> 


					<a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_CDelete" href="#CDelete">Delete</a>

					<b><a  class="list-group-item ScrollToElement" ScrollObjID="ScrollTo_LocalStorage" href="#LocalStorage">Local Storage</a></b>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAdd" href="#LSAdd">Add</a>				
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSGet" href="#LSGet">Get</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAddObj" href="#LSAddObj">Add Object</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSGetObj" href="#LSGetObj">Get Object</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSUpdateObj" href="#LSUpdateObj">Update Object</a>
					

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAddArr" href="#LSAddArr">Add Array</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAddTempArr" href="#LSAddTempArr">Add Temp Array</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAddBulkObj" href="#LSAddBulkObj">Add Bulk Array</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSAddTempBulkArr" href="#LSAddTempBulkArr">Add Temp Bulk Array</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSGetArr" href="#LSGetArr">Get Array</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSGetAllArr" href="#LSGetAllArr">Get All Arrays</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSGetArrCount" href="#LSGetArrCount">Get Array Count</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSUpdateArr" href="#LSUpdateArr">Update Array</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSDeleteArr" href="#LSDeleteArr">Delete Array</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSExist" href="#LSExist">Exist</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSEmpty" href="#LSEmpty">Empty</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSDelete" href="#LSDelete">Delete</a> 
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_LSDeleteAll" href="#LSDeleteAll">Delete All Storages</a> 

					
					<br><br>
				</div>
				<br><br>
			</div>
			<br><br>
			
		</div> 
		<!--[Right Side Bar - End]-->
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->


<?php include('footer.php') ?>
	
</body>

</html> 