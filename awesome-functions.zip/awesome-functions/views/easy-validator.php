<!DOCTYPE html>
<html>
<head>

	<title>Easy Validator - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This JS library has a lot of useful and powerful JS and PHP functions that will help you build awesome client side web applications">
 
	
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{ 
		$('.alert-success').hide();

		$(document).on('click', '.Login_Btn', function(event) 
		{
			event.preventDefault();

			//will return a json object with values that you can send to your server
			var check = $(document).find('.LoginForm').easyvalidator();

			if(check )
			{				
				var d = ''
				+'<br><br>'
				+'<p>Below is the object with data that you can send to your server: <p>'
				+'<br><br>'
				+ '<pre>'+JSON.stringify(check,"\t",2) + '</pre>'
				+'<br><br>'
				+'';
				$('.alert-success').append(d).show();

				$('.panel').hide();				

				//now you can send data to your server via ajax or other ways
			}
		});
 
	 
	}); 
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding-top:100px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	 

	
	<div class="center-page c1ol-md-6">  

		<h1 class="text-center">Easy Validator</h1>

		<p>With this you can easily validate your entries.</p> 
		 
		<h3>Usage</h3>			 
<pre class="bg-success ">
//add this to your attributes to your input fields

af-input    = add the class to your field

ev-obj-name = this will become the json object name 

ev-msg      = an alert message your user will see 

required    = if you want to make the field required...which means your user will have to fill in the info 

</pre> 
	
	<h3>Examples</h3>	

<pre class="bg-success ">

//example > simple
&lt;input type="password" class="af-input" ev-obj-name="user_password">

//example > custom alert
&lt;input type="text" class="af-input" required ev-obj-name="user_name" ev-msg="enter user name 123">


//You can use custom types: input, textarea, checkbox, select

use this attribute > ev-type="select"

//custom > dropdown list
&lt;select class="af-input" required  ev-type="select" ev-msg="You need to select one"  ev-obj-name="user_selection_option">
	&lt;option value="" >Please select one &lt;/option>
	&lt;option value="saab">Saab &lt;/option>
	&lt;option value="mercedes">Mercedes &lt;/option>
	&lt;option value="audi">Audi &lt;/option>
&lt;/select>


</pre> 
	
	<h3>Calling it in your javascript</h3>
<pre class="bg-success ">

$(document).on('click', '.Login_Btn', function(event) 
{
	event.preventDefault();

	//this the top contianer element where you fields are in
	var e0 = $(document).find('.LoginForm');

	//will return a json object with values that you can send to your server
	var check = e0.easyvalidator();

	if(check )
	{				
		//check variable will have your json object
	}
}); 
</pre> 
		<a class="btn btn-primary BtnIsMobile" role="button" data-toggle="collapse" href="#Collapse_EasyValidator" aria-expanded="false" aria-controls="Collapse_EasyValidator" >Example</a>	


		<br><br><br>

		<div class="collapse" id="Collapse_EasyValidator"> 

	
			<div class="center-page col-md-6">  
			 	
			 	<div class="spacer-3x" ></div>
				<div class="alert alert-success" style="display:none;">
					<strong>Validation Completed!</strong>  
				</div>
			  
			    <div class="panel panel-default" style=" border-radius: 50px;">


			        <div class="panel-body">
			       		
			       		<div class="text-center">
						<h2 >Easy Validator</h2>
					 
						<em class="required text-center">*required</em>
						</div>
						<br> 
						<div style="display:none" class="LoginAlert"></div>

						<!--[Login Form - End]-->
						<div class="LoginForm ">
							
							<!--[user name > start]-->
							<div>
								<i class="glyphicon glyphicon-user spacer-3x" aria-hidden="true"></i>
								<em class="required">*</em>
								<input type="text" class="af-input Login_Frm Login_ID " required ev-obj-name="user_name" ev-msg="enter user name 123"   placeholder="User ID">
								
							</div>
							<br><br>
							<!--[user name > end]-->
							
							<!--[user password > start]-->	
							<div>			
								<i class="glyphicon glyphicon-user spacer-3x"   aria-hidden="true"></i>
								<em class="required">*</em>
								<input type="password" class="af-input Login_Frm Login_ID " required  ev-obj-name="user_password"  placeholder="password">
							</div>
							<br><br>
							<!--[user password > end]-->				
							
							
							<!--[user password > start]-->	
							<div>			
								<i class="glyphicon glyphicon-chevron-right spacer-3x"></i>					 
								<input type="number" class="Login_Frm Login_ID " ev-type="number"   ev-obj-name="user_num"  placeholder="number">			 
							</div>
							<br><br>
							<!--[user password > end]-->				 
							
							<div class="">					
								<i class="glyphicon glyphicon-envelope spacer-3x"></i>
								<em class="required">*</em>
								<input type="email" class="af-input Login_Frm Login_Password" required ev-obj-name="user_email"   placeholder="User email">
							</div>
							<br><br>

							<div class="">
								<i class="glyphicon glyphicon-lock spacer-3x" aria-hidden="true"></i>
								<input type="url" class="Login_Frm Login_Password  "   ev-obj-name="url" placeholder="http://1estore.com"> 
								
							</div>
							<br><br>

							<div class="">					
								<i class="glyphicon glyphicon-comment"></i>
								<em class="required">*</em>
								<textarea class="af-input" 1ev-type="text" cols="50" rows="3"  ev-obj-name="user_comment" required placeholder="type your comments here... "></textarea>
							</div>
							<br><br>


							<br><br>
							<em class="required">*</em>
							<input type="checkbox" name="vehicle1" value="Bike" required  ev-obj-name="user_check_option"> I have a bike required<br>
							<input type="checkbox" name="vehicle2" value="Car"> I have a car<br>
							<input type="checkbox" name="vehicle3" value="Boat" checked> I have a boat<br><br>
							
							<br><br>
							<em class="required">*</em>
							<select class="af-input" required  ev-type="select" ev-msg="You need to select one"  ev-obj-name="user_selection_option">
								<option value="" >Please select one</option>
								<option value="saab">Saab</option>
								<option value="mercedes">Mercedes</option>
								<option value="audi">Audi</option>
							</select>
							<br><br>
							
							<div class="text-center">
								<button class="btn   Login_Btn text-center " type="button">Validate Data</button>
							</div>
							
							<br><br>
						</div>
			        <!--[Login Form - End]-->

			        </div>
			    </div> 
			</div>  
	
		</div>
		 
			
	</div>	 

</div>
<!--[Container - End]-->

<?php include('footer.php') ?>
	
</body>

</html>