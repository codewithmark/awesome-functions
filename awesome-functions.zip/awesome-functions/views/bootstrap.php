<!DOCTYPE html>
<html>
<head>

	<title>Bootstrap - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This JS library has a lot of useful and powerful JS and PHP functions that will help you build awesome client side web applications">
 
	
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{
		//console.clear(); 
		$('[data-toggle="tooltip"]').tooltip();
				
	
		
	});
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row"> 

		<div class="col-md-9">
			<h1 class="text-center">Bootstrap</h1>	
			<p  class="text-center">These functions have dependency on Boostrap CSS and Awesome Fonts for some awesomeness</p> 
			

			<!--[ShowError - Start]-->
			<span class="ScrollTo_ShowError" id="ShowError" ></span>
			<h3  class="page-header">Show Error</h3>
			<p>This will create an error alert after the element</p>	 
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.ShowError (errorText,ElementObjID) 

//Exampel 1
bs.ShowError ('Invaild User Name', $('.UserName')) 

//Exampel 2
bs.ShowError ('Invaild Email Address', $('#UserEmail')) 

</pre>
			<p>This is ideal for when you are validating the user entries.</p>
			
	 		
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_ShowError" aria-expanded="false" aria-controls="Collapse_ShowError" >Example</a>			
			<div class="collapse" id="Collapse_ShowError">
				<br>
				
				 <div id="derr" class="derr alert alert-danger  form-control" style="padding:5px;font-size:14px"  > 
					 <i class="fa fa-exclamation-triangle "></i> This is an example error message
				</div>
				
			</div> 
		 
			<!--[ShowError - End]-->

			<!--[ClearError - Start]-->
			<span class="ScrollTo_ClearError" id="ClearError"  ></span>
			<h3  class="page-header">Clear Error</h3> 
			<p>This will clear all of the "bs.ShowError()" messgaes.</p> 
		 
		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.ClearError();
</pre>
			<p>If you are using the bs.ShowError funciton, then call this function at the top of your validation process.</p>
			<p> This way all of the errorr messages are clear from your user screen.</p> 
			 
			<!--[ClearError - End]-->

		<!--[WaitingMsg - Start]-->
		<span class="ScrollTo_WaitingMsg" id="WaitingMsg" ></span>
		<h3  class="page-header">Waiting Msg</h3>
		<p>When you are waiting for you process to finish doing its thing, generally it's a good practice to tell your user to please wait.</p>
		<p>This function definitely makes it easier for you to do that. </p>

			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.WaitingMsg(Msg)

//Example
var d = bs.WaitingMsg("Please wait....Processing your request");

//The element where you want to show the message
$('#UserMsg').html(d);

$('.UserMsg').html(d);
</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_WaitingMsg" aria-expanded="false" aria-controls="Collapse_WaitingMsg" >Example</a>	
			
			<div class="collapse" id="Collapse_WaitingMsg">
			<br>		
				<div id="MsgBox" id="derr" class="derr bg-info alert alert-info derr" style="font-size: 40px;padding:10px;">
					<i class="fa fa-refresh fa-spin "></i> Please wait...processing your request..
				</div>
			</div>
			<br><br><br><br>		

			<!--[WaitingMsg - End]-->
			
			
			
			<!--[AlertMsg - Start]-->
		<span class="ScrollTo_AlertMsgg" id="AlertMsg" ></span>
		<h3  class="page-header">Alert Msg</h3>
		<p>Alerts are a great way to inform your users of specific action you want them to take. </p>
		<p>This function offers 4 different types of alerts you can easily use to inform your users. </p>
		<ul>
			<li>success</li>
			<li>error</li>
			<li>info</li>
			<li>warning</li>
		</ul>


			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.AlertMsg (MsgData,AlertType)


var d;

//Example 1
d = bs.AlertMsg("We have emailed you a new password", "success");

//Example 2
d = bs.AlertMsg("Oppss... invaild email address...", "error");

//Example 3
d = bs.AlertMsg("your request was submitted successfully....", "info");

//Example 4
d = bs.AlertMsg("Looks like this email is already taken", "warning");


//The element where you want to show the alert
$('#UserMsg').html(d);

$('.UserMsg').html(d);
</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_AlertMsg" aria-expanded="false" aria-controls="Collapse_AlertMsg" >Examples</a>	
			
			<div class="collapse" id="Collapse_AlertMsg">
			<br>		

				
				<!--[Success Alert - Start]-->
				<div class="derr alert alert-success"  >
					<div style="padding:5px;font-size:16px">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> 
						Success alert message
					</div>
				</div>
				<!--[Success Alert - End]-->
				
				<!--[Error Alert - Start]-->
				<div class="derr alert alert-danger"  >
					<div style="padding:5px;font-size:16px">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> 
						Error alert message
					</div>
				</div>
				<!--[Error Alert - End]-->
				
				<!--[Info Alert - Start]-->
				<div class="derr alert alert-info"  >
					<div style="padding:5px;font-size:16px">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> 
						Info alert message
					</div>
				</div>
				<!--[Info Alert - End]-->
				
				<!--[Warning Alert - Start]-->
				<div class="derr alert alert-warning"  >
					<div style="padding:5px;font-size:16px">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> 
						Warning alert message
					</div>
				</div>
				<!--[Warning Alert - End]-->
				
			</div>
			<br><br><br><br>		

			<!--[AlertMsg - End]-->

			<!--[ConfirmAlert - Start]-->
         <span class="ScrollTo_Confirm"  id="Confirm" ></span>
         <h3  class="page-header">Confirm Alert</h3>
         <p>If you ever wanted to confirm your users to action before actually performing the task, this function can easily let you do that.</p>

         
         <b>Usage</b>          
<pre class="bg-success ">
//Syntax  

var ObjArrOptions = 
{
  text: "Are you sure you want to delete that comment?",
  title: "Confirmation required",
  confirm: function(button) 
  {
    //Call your delete function
    delete();

    //or run the delete process like this
    var TopDiv = $('.Container').remove();

  },
  cancel: function(button) 
  {
    // nothing to do
  },
  confirmButton: "Yes I am",
  cancelButton: "No",                       
  confirmButtonClass: "btn-danger",    //Bootstrap button class
  cancelButtonClass: "btn-default",    //Bootstrap button class
  dialogClass: "modal-dialog modal-lg" // Bootstrap classes for large modal
}

//Call is like this
bs.confirm(ObjArrOptions);

 
</pre> 
         <a class="btn btn-primary " role="button" data-toggle="collapse" href="#Collapse_Confirm" aria-expanded="false" aria-controls="Collapse_Confirm" >Example</a> 
         
         <div class="collapse" id="Collapse_Confirm">
            <br>  
            <p class="PrintThisContent">When you click on the button below, it will show a confirmation modal</p>
            <br>
            <div class="btn btn-success btn_Confirm">Confirm Alert </div>
            <div class="DeleteConfirmAction"></div>
            
            <script>
            $(document).on('click', '.btn_Confirm', function(event) 
            {
               event.preventDefault();
               
               //bs.ClearError();

               var ObjArrOptions = 
               {
                 text: "Are you sure you want to delete that comment?",
                 title: "Confirmation required",
                 confirm: function(button) 
                 {
                     
                     //Run the delete process like this
                     var d = bs.AlertMsg("This is a delete confirmation of deleting comment", "error");
                     $('.DeleteConfirmAction').html(d);

                 },
                 cancel: function(button) 
                 {
                   // nothing to do
                 },
                 confirmButton: " Yes I am",
                 cancelButton: "No",                       
                 confirmButtonClass: "btn-danger",    //Bootstrap button class
                 cancelButtonClass: "btn-default",    //Bootstrap button class
                 dialogClass: "modal-dialog modal-lg" // Bootstrap classes for large modal
               }

               bs.confirm(ObjArrOptions);
 
               
            })
            </script>
 
         </div>

   
         <!--[Confirm  - End]-->


			<!--[CheckingMsg - Start]-->
		<span class="ScrollTo_CheckingMsg" id="CheckingMsg" ></span>
		<h3  class="page-header">Checking Msg</h3>
		<p>Another great way to show a message to your users is under the input field. </p>
		<p>For example, if you are updating a field via an Ajax call, you can show a message that says "please wait updating" or something like that. This way your user know something is happening. </p>

			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.CheckingMsg(ElementObjID,Msg)

//Example 1
bs.CheckingMsg($('#UserMsg'),"Please wait....Processing your request");


//Example 2
bs.CheckingMsg($('.UserMsg'),"Please wait....Processing your request");

 
</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CheckingMsg" aria-expanded="false" aria-controls="Collapse_CheckingMsg" >Example</a>	
			
			<div class="collapse" id="Collapse_CheckingMsg">
				<br>	
				 <div>
					 <input type="text"  class="form-control " value="info@gmail.com">
						<div id="derr" class="derr alert alert-warning " role="alert"> 
							<i class="fa fa-spinner fa-spin"></i> Please wait....Processing your request
						</div>
				 </div>
			</div>
		

			<!--[CheckingMsg - End]-->
			
			
			
			<!--[CreateButton - Start]-->
		<span class="ScrollTo_CreateButton" id="CreateButton" ></span>
		<h3  class="page-header">Create Button</h3>
		<p>This function easily allows you to create a button with just one line of code </p>
			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.CreateButton (ButtonText,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the button element.
//i.e. custom attr (rec_id="1343")

//Example 1
//Just add the button text and id
var d = bs.CreateButton ("Save","btn_Save")

//Example 2
//Just add the button text and class name
//you can also use bootstrap button classese as well in the class parameter
var d = bs.CreateButton ("Save","", "btn_ClassSave btn-success")

//Example 3
//Just add the button text, id, and addon
var d = bs.CreateButton ("Save","btn_Save", "", 'rec_id="12456", post_id="500" ')

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateButton" aria-expanded="false" aria-controls="Collapse_CreateButton" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateButton">
				<br>	
			 
				<div class="CreateButton"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = bs.CreateButton (" This is awesome function Button"," ",'btn-success' );
					$('.CreateButton').html(d);
				})
				</script>
				
			</div>
			<!--[CreateButton - End]-->
			
			
			
			<!--[CreateInputField - Start]-->
		<span class="ScrollTo_CreateInputField" id="CreateInputField" ></span>
		<h3  class="page-header">Create Input Field</h3>
		<p>This function easily allows you to create an Input Field with just one line of code </p>
			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.CreateInputField (Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example 1
//Empty input field with id 
var d = bs.CreateInputField ("","user_email")

//Example 2
//InputField Value and class name
var d = bs.CreateInputField ("john smith","", "user_name")

//Example 3
//InputField value, id, and addon
var d = bs.CreateInputField ("john smith","user_name", "", 'rec_id="12456", post_id="500" ')

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);

</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateInputField" aria-expanded="false" aria-controls="Collapse_CreateInputField" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateInputField">
				<br>	
				<div class="CreateInputField"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = bs.CreateInputField ("","user_name", "", 'placeholder="Create Input Field"');
					$('.CreateInputField').html(d);
				})
				</script>
				
			</div>
			

			<!--[CreateInputField - End]-->			
	
			
			<!--[CreateHiddenInputField - Start]-->
		<span class="ScrollTo_CreateHiddenInputField" id="CreateHiddenInputField" ></span>
		<h3  class="page-header">Create Hidden Input Field</h3>
		<p>This function easily allows you to create a Hidden Input Field with just one line of code so you can store some data that you don't want your users to see.</p>
		<p>But use the field value later on for your data processing</p>
			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.CreateHiddenInputField (Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example 1
//Empty input field with id 
var d = bs.CreateHiddenInputField ("","user_email")

//Example 2
//InputField Value and class name
var d = bs.CreateHiddenInputField ("john smith","", "user_name")

//Example 3
//InputField value, id, and addon
var d = bs.CreateHiddenInputField ("john smith","user_name", "", 'rec_id="12456", post_id="500" ')

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<!--[CreateHiddenInputField - End]-->			
			
			
			<!--[CreateHiddenInputField - Start]-->
		<span class="ScrollTo_CreateCustomInputField" id="CreateCustomInputField" ></span>
		<h3  class="page-header">Create Custom Input Field</h3>
		<p >You can easily create a custom input field with one of the 12 html5 data types:</p>

		<ul>
			<li >
			<p  >color</p>
			</li>
			<li  >
			<p  >email</p>
			</li>
			<li >
			<p  >number</p>
			</li>
			<li  >
			<p  >search</p>
			</li>
			<li >
			<p  >time</p>
			</li>
			<li >
			<p >week</p>
			</li>
			<li >
			<p >date</p>
			</li>
			<li >
			<p  >text</p>
			</li>
			<li >
			<p  >month</p>
			</li>
			<li >
			<p  >rage</p>
			</li>
			<li >
			<p  >tel</p>
			</li>
			<li  >url</li>
		</ul>

			
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateCustomInputField(FieldType,Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example 1
var d = bs.CreateCustomInputField ("number",1234, 'rec_id')

//Example 2
var d = bs.CreateCustomInputField ('text',"john smith","", "user_name")

//Example 3
//for best result run your date or time value through js.FormatDateTime()
var d = bs.CreateCustomInputField ('date',js.FormatDateTime  ('YourValue','YYYY-MM-DD'),"user_date", "", )

var d = bs.CreateCustomInputField ('time', js.FormatDateTime  ('YourValue','kk:mm'),"user_date", "", )

var d = bs.CreateCustomInputField ('month', js.FormatDateTime  ('YourValue','YYYY-MM'),"user_date", "", )


//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateCustomInputField" aria-expanded="false" aria-controls="Collapse_CreateCustomInputField" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateCustomInputField">
				<br>	
				<div class="CreateCustomInputField"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = '';
					d += 'Number: '+ bs.CreateCustomInputField ("number",1234, 'rec_id') + '<br>';
					d += 'time: '+ bs.CreateCustomInputField ("time",js.FormatDateTime  ('','kk:mm'), 'tm', '') + '<br>';
					d += 'Date: '+ bs.CreateCustomInputField ("date", js.FormatDateTime  ('','YYYY-MM-DD'), 'dte', '') + '<br>';
					d += 'Month: '+ bs.CreateCustomInputField ("month", js.FormatDateTime  ('','YYYY-MM'), 'month', '') + '<br>';
					$('.CreateCustomInputField').html(d);
				})
				</script>
				
			</div>
			<!--[CreateCustomInputField - End]-->			
			
			
			
			
			<!--[CreateGroupInputField - Start]-->
		<span class="ScrollTo_CreateGroupInputField" id="CreateGroupInputField" ></span>
		<h3  class="page-header">Create Group Input Field</h3>
		<p >You can easily create a group input field</p> 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateGroupInputField (GroupName,Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example  
var d = bs.CreateGroupInputField ("User Name","John Smith", 'rec_id')
 

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateGroupInputField" aria-expanded="false" aria-controls="Collapse_CreateGroupInputField" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateGroupInputField">
				<br>	
				<div class="CreateGroupInputField"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = '';
					d +=  bs.CreateGroupInputField ("User Name",'', 'user_id','', ' placeholder="Create Group Input Field" ') + '<br>';
				 
					$('.CreateGroupInputField').html(d);
				})
				</script>
				
			</div>
			<!--[CreateGroupInputField - End]-->		
			
			
			
			<!--[CreateCustomGroupInputField - Start]-->
		<span class="ScrollTo_CreateCustomGroupInputField" id="CreateCustomGroupInputField" ></span>
		<h3  class="page-header">Create Custom Group Input Field</h3>
		<p>You can easily create a custom group input field</p> 
		<p>Just like "Create Custom Input Field" function, you can use html5 data type for this function as well. </p>	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateCustomGroupInputField (FieldType,GroupName,Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example  
var d = bs.CreateCustomGroupInputField ("date", "Today's  Date", js.FormatDateTime  ('','YYYY-MM-DD'), 'dte', '')
 

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateCustomGroupInputField" aria-expanded="false" aria-controls="Collapse_CreateCustomGroupInputField" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateCustomGroupInputField">
				<br>	
				<div class="CreateCustomGroupInputField"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = '';
					d += bs.CreateCustomGroupInputField ("date", "Today's  Date", js.FormatDateTime  ('','YYYY-MM-DD'), 'dte', '') + '<br>';
				 
					$('.CreateCustomGroupInputField').html(d);
				})
				</script>
				
			</div>
			<!--[CreateCustomGroupInputField - End]-->		
			
			
			<!--[CreateCustomGroupInputField - Start]-->
		<span class="ScrollTo_CreateTextBox" id="CreateTextBox" ></span>
		<h3  class="page-header">Create Text Box</h3>
		<p>You can easily create a text box with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateTextBox (Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example  
var d = bs.CreateTextBox ('Thi is a text box text', 'user_txt')
 

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateTextBox" aria-expanded="false" aria-controls="Collapse_CreateTextBox" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateTextBox">
				<br>	
				<div class="CreateTextBox"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = '';
					d += bs.CreateTextBox ('This is a text box text', 'user_txt') + '<br>';
				 
					$('.CreateTextBox').html(d);
				})
				</script>
				
			</div>
			<!--[CreateTextBox - End]-->		
			
			
			<!--[CreateGroupTextBox - Start]-->
		<span class="ScrollTo_CreateGroupTextBox" id="CreateGroupTextBox" ></span>
		<h3  class="page-header">Create Group Text Box</h3>
		<p>You can easily create a group text box with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateGroupTextBox(GroupName,Value,ID,Class,Addon)

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example  
var d = bs.CreateGroupTextBox ('User Text', 'This is a text box text', 'user_txt')
 

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateGroupTextBox" aria-expanded="false" aria-controls="Collapse_CreateGroupTextBox" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateGroupTextBox">
				<br>	
				<div class="CreateGroupTextBox"></div>
				<script>

            	$(document).ready(function()
            	{
					var d = '';
					d += bs.CreateGroupTextBox ('User Text', 'This is a text box text', 'user_txt') + '<br>';
				 
					$('.CreateGroupTextBox').html(d);
				})
				</script>
				
			</div>
			<!--[CreateGroupTextBox - End]-->		
			
			
			<!--[CreateGroupTextBox - Start]-->
		<span class="ScrollTo_CreateDropDownList" id="CreateDropDownList" ></span>
		<h3  class="page-header">Create Drop Down List</h3>
		<p>You can easily create a drop down list with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
var d = bs.CreateDropDownList(LabelText,Options, Value, ID,Class,Addon);

//Note Addon can you be anything you would like to add to the element.
//i.e. custom attr (rec_id="1343")

//Example
var Options = 'Breakfast, Lunch, Dinner';
var d = bs.CreateDropDownList ('Meal Options', Options, '','meal_list');

var d = bs.CreateDropDownList ('Meal Options', Options, 'Lunch','','meal_list');
 

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_CreateDropDownList" aria-expanded="false" aria-controls="Collapse_CreateDropDownList" >Example</a>	
			
			<div class="collapse" id="Collapse_CreateDropDownList">
				<br>	
				<div class="CreateDropDownList"></div>
				<script>

            	$(document).ready(function()
            	{
					var Options = 'Breakfast, Lunch, Dinner';
					var d = '';
					d += bs.CreateDropDownList ('Meal Options', Options, '','meal_list') + '<br>';
					d += bs.CreateDropDownList ('Meal Options With User Value', Options, 'Lunch','meal_list') + '<br>';
				 
					$('.CreateDropDownList').html(d);
				})
				</script>
				
			</div>
			<!--[CreateDropDownList - End]-->		
			



			<!--[Tabs - Start]-->
		<span class="ScrollTo_Tabs" id="Tabs" ></span>
		<h3  class="page-header">Create Tabs</h3>
		<p>You can easily create tabs with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Example
var arr = 
[ 
 {tab_name:'tab 1', tab_content: "this is my tab 1 contain"},
 {tab_name:'tab 2', tab_content: "this is my tab 2 "},
]
var d = bs.Tabs(arr);

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_Tabs" aria-expanded="false" aria-controls="Collapse_Tabs" >Example</a>	
			
			<div class="collapse" id="Collapse_Tabs">
				<br>	
				<div class="CreateTabs"></div>
				<script>

            	$(document).ready(function()
            	{
					var arr = 
					[ 
					 {tab_name:'tab 1', tab_content: "this is my tab 1 contain"},
					 {tab_name:'tab 2', tab_content: "this is my tab 2 "},
					]
					var d = bs.Tabs(arr);

					//Out in a div 				 
					$('.CreateTabs').html(d);
				})
				</script>
				
			</div>
			<!--[Tabs - End]-->	
			


			<!--[Panel - Start]-->
		<span class="ScrollTo_Panel" id="Panel" ></span>
		<h3  class="page-header">Create Panel</h3>
		<p>You can easily create Panel with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Example
var object_data =
{
 panel_header:'header', 
 panel_content: "this is my panel 1 content",
 panel_footer: "footer",
 panel_class: "default", 
}

var d = bs.Panel(object_data);

//Out in a div 
$('#MyDivID').html(d);

$('.MyDivClass').html(d);
</pre> 
			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_Panel" aria-expanded="false" aria-controls="Collapse_Panel" >Example</a>	
			
			<div class="collapse" id="Collapse_Panel">
				<br>	
				<div class="CreatePanel"></div>
				<script>

            	$(document).ready(function()
            	{
					var object_data =
					{
						panel_header:'header', 
						panel_content: "this is my panel 1 content",
						panel_footer: "footer",
						panel_class: "default", 
					}

					var d = bs.Panel(object_data);


					//Out in a div 				 
					$('.CreatePanel').html(d);
				})
				</script>
				
			</div>
			<!--[Panel - End]-->


			<!--[Modal - Start]-->
		<span class="ScrollTo_Modal" id="Modal" ></span>
		<h3  class="page-header">Create Modal</h3>
		<p>You can easily create Modal with this function</p> 	
			 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
bs.Modal(object_data);

//Example  
$(document).on('click', '.btn_demo_modal', function(event) 
{ 
 var object_data =
 {
   ModalTitle:'Modal Title', 
   ModalBodyContent: "this is my Modal Body Content ",
 }
 
 bs.Modal(object_data);

});
</pre> 
			<br> 
			<div class="btn btn-primary btn_demo_modal"   >Example</div>	

				<script>

            	$(document).ready(function()
            	{
            		$(document).on('click', '.btn_demo_modal', function(event) 
            		{
            			event.preventDefault();
            			
            			
            			var d1 = ' '
            			d1+= "this is my Modal Body Content"

            			for (var i = 1; i <= 5; i++) 
            			{
            				var id = Math.random().toString(36).substr(2);
            				d1+= '<br><br>'
            				d1+= "This is a random string "+i+"  >>> "+id
            			}
            			d1+= ''
            			 

						var object_data =
						{
							ModalTitle:'Modal Title', 
							ModalBodyContent: d1,
						}
 						bs.Modal(object_data);
            		});
				})
				</script>
				
			
			<!--[Modal - End]-->


			
		 
			<br><br><br><br>
		</div>
		
		<!--[Right Side Bar - Start]-->
		<div class="col-md-3  ">			
			<div  class="sidebar-nav-fixed pull-right affix" style="max-height:100vh; overflow: auto;">
				
			
				<p class="lead text-center">Functions</p>
				<div class="list-group ">
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_ShowError" href="#ShowError">Show Error</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_ClearError" href="#ClearError">Clear Error</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_WaitingMsg" href="#WaitingMsg">Waiting Msg</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_AlertMsg" href="#AlertMsg">Alert Msg</a>
					
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Confirm" href="#Confirm">Confirm</a>

					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CheckingMsg" href="#CheckingMsg">Checking Msg</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateButton" href="#CreateButton">Create Button</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateInputField" href="#CreateInputField">Create Input Field</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateHiddenInputField" href="#CreateHiddenInputField">Create Hidden Input Field</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateCustomInputField" href="#CreateCustomInputField">Create Custom Input Field</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateGroupInputField" href="#CreateGroupInputField">Create Group Input Field</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateCustomGroupInputField" href="#CreateCustomGroupInputField">Create Custom Group Input Field</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateTextBox" href="#CreateTextBox">Create Text Box</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateGroupTextBox" href="#CreateGroupTextBox">Create Group Text Box</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_CreateDropDownList" href="#CreateDropDownList">Create DropDown List</a>
	 
	 				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Tabs" href="#Tabs">Tabs</a>	 				
	 				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Panel" href="#Panel">Panel</a>
	 				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Modal" href="#Modal">Modal</a>
	 
	 
				<br><br>
				</div>
				<br><br>
			</div>
			
		</div>
		
		
		<!--[Right Side Bar - End]-->
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->

<?php include('footer.php') ?>
	
</body>

</html>