<?php if ( !defined('ABSPATH') )  die('403 Forbidden – Access Denied ');?>
<!DOCTYPE html>
<html lang="en">
<head>

	<title>404 Page </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"  ></script>

</head> 

<style type="text/css"> 
html,body{height:100%;background-color:#556}
@media (min-width:768px){.main-container{width:100%}}
@media (min-width:992px){.container{width:600px}}
</style>

<body >





<div style=" padding:35px;"> </div> 

<div class="ScreenData container" style="max-width : 1000px; margin : 0 auto; border: 1px dotted #CCC;padding : 20px;background : #FFF; border-radius: 50px;">
    <div style="text-align: center;  ">
        <i class="fa fa-frown-o" style="font-size:200px;"></i>
        <div style="text-align: center;"><span style="font-size:48px">Oh...No</span></div>
        <br>
        <br>
        <p style="text-align: center;"><span style="font-size:28px">Can't Find Your Page....</span></p>
        <br>
        <br>
        <a class="btn btn-success" href="<?php echo APPURL; ?>"> 

            <i class="fa fa-arrow-left fa-2x "></i> <span style="padding:4px;"></span> Go Home 
        </a>
    </div>
    <br>
    <br>
    <div class="container-fluid"></div>
</div>

</body>



</html>