<!--[CSS/JS Files - Start]-->

<link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">


<script    src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script    src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script> 

 
<script   src="https://af.apidelv.com/awesome-functions.min.js"></script> 

<?php
//https://cdn.apidelv.com/libs/awesome-functions/awesome-functions.min.js
//src="/cdn/awesome-functions.min.js"
//<script src="https://cdn.awesomefunctions.com/awesome-functions.min.js">
//<script src="https://cdn.apidelv.com/libs/awesome-functions/awesome-functions.min.js">

//https:
//$plugin_files = file_get_contents($_SERVER["DOCUMENT_ROOT"]."/cdn/awesome-functions.min.js");
//echo np_minify_js(file_get_contents("/cdn/awesome-functions.min.js"));
?>



<style type="text/css">
	<?php 
	 	//echo np_minify_css(file_get_contents("assets/style.css"));
		echo  (file_get_contents(ABSPATH_Folder_Path_Views."/css/style.css"));
	?>
</style>

<script type="text/javascript">
console.log("%c  😊 Thanks for using Awesome Functions! 😊", "font: 1.5em roboto; color: #dd4814;");
<?php  
	//echo np_minify_js(file_get_contents("js/app.js"));
	echo (file_get_contents(ABSPATH_Folder_Path_Views."/js/app.js"));
?>
</script>	

 



 