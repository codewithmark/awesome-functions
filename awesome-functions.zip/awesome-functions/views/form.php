<!DOCTYPE html>
<html>
<head>

	<title>Form Validator - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This Awesome Functions  library has a lot of easy to use functions that will help you build awesome client side web applications faster then you can imagine">
	 
	
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{	
		//console.clear(); 
		
		$('[data-toggle="tooltip"]').tooltip();
	});
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row"> 

		<div class="col-md-9">
			<h1 class="text-center">Form Validator</h1>	
			<p class="text-center">These functions have dependency on jQuery</p> 
			<br>	<br>
			<p>With these user-friendly  functions you can easily valid your form for different things</p> 	
				
			
	 

			<!--[IsEmpty - Start]-->
			<span class="ScrollTo_IsEmpty" id="IsEmpty" ></span>
			<h3  class="page-header">Is Empty</h3>
			<p>With this function you can easily check to see if your input field is empty or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsEmpty(value) 

//Example
$('.btn_Validate_IsEmpty').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsEmpty').val();
 
 // Validate field
 if(frm.IsEmpty(d))
 {
  //Show alert
  bs.ShowError ("Please enter text",$('.field_IsEmpty'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsEmpty" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsEmpty">
				<br><br>
				
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsEmpty"></div>
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsEmpty');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsEmpty');
					
					$('.Div_IsEmpty').html(d);
					
					$('.btn_Validate_IsEmpty').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsEmpty').val();
						if(frm.IsEmpty(d))
						{
							bs.ShowError ("Please enter text",$('.field_IsEmpty'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsEmpty - End]-->
 

			<!--[IsAlphaNumeric - Start]-->
			<span class="ScrollTo_IsAlphaNumeric" id="IsAlphaNumeric" ></span>
			<h3  class="page-header">Is Alpha Numeric</h3>
			<p>With this function you can easily check to see if your input field is alpha numeric or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsAlphaNumeric(value) 

//Example
$('.btn_Validate_IsAlphaNumeric').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsAlphaNumeric').val();
 
 // Validate field
 if(frm.IsAlphaNumeric(d))
 {
  //Show alert
  bs.ShowError ("Please enter Alpha Numeric value ",$('.field_IsAlphaNumeric'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsAlphaNumeric" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsAlphaNumeric">
				<br><br>
				
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsAlphaNumeric"></div>
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsAlphaNumeric');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsAlphaNumeric');
					
					$('.Div_IsAlphaNumeric').html(d);
					
					$('.btn_Validate_IsAlphaNumeric').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsAlphaNumeric').val();
						if(frm.IsAlphaNumeric(d))
						{
							bs.ShowError ("Please enter Alpha Numeric value ",$('.field_IsAlphaNumeric'))
						}
					})
				})					
				</script> 
			</div> 
			<br><br> 
			<!--[IsAlphaNumeric - End]-->
			
			
			<!--[IsNoSpaces - Start]-->
			<span class="ScrollTo_IsNoSpaces" id="IsNoSpaces" ></span>
			<h3  class="page-header">Is No Spaces</h3>
			<p>With this function you can easily check to see if your input field contains any spaces or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsNoSpaces(value) 

//Example
$('.btn_Validate_IsNoSpaces').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsNoSpaces').val();
 
 // Validate field
 if(frm.IsNoSpaces(d))
 {
  //Show alert
  bs.ShowError ("Please enter value with no spaces ",$('.field_IsNoSpaces'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsNoSpaces" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsNoSpaces">
				<br><br>
				
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsNoSpaces"></div>
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsNoSpaces');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsNoSpaces');
					
					$('.Div_IsNoSpaces').html(d);
					
					$('.btn_Validate_IsNoSpaces').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsNoSpaces').val();
						if(frm.IsNoSpaces(d))
						{
							bs.ShowError ("Please enter value with no spaces ",$('.field_IsNoSpaces'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsNoSpaces - End]-->
			
			
			<!--[IsEmail - Start]-->
			<span class="ScrollTo_IsEmail" id="IsEmail" ></span>
			<h3  class="page-header">Is Email</h3>
			<p>With this function you can easily check to see if the email address is vaild or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsEmail(value) 

//Example
$('.btn_Validate_IsEmail').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsEmail').val();
 
 // Validate field
 if(frm.IsEmail(d))
 {
  //Show alert
  bs.ShowError ("Invaid Email ",$('.field_IsEmail'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsEmail" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsEmail">
				<br><br>
				
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsEmail"></div>
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsEmail');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsEmail');
					
					$('.Div_IsEmail').html(d);
					
					$('.btn_Validate_IsEmail').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsEmail').val();
						if(frm.IsEmail(d))
						{
							bs.ShowError ("Invaid Email ",$('.field_IsEmail'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsEmail - End]-->
			 
			
			
			<!--[IsURL - Start]-->
			<span class="ScrollTo_IsURL" id="IsURL" ></span>
			<h3  class="page-header">Is URL</h3>
			<p>With this function you can easily check to see if the URL address is vaild or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsURL(value) 

//Example
$('.btn_Validate_IsURL').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsURLl').val();
 
 // Validate field
 if(frm.IsURL(d))
 {
  //Show alert
  bs.ShowError ("Invalid URL ",$('.field_IsURL'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsURL" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsURL">
				<br><br>
				
				
				<p>Valid URL includes the following: 	</p>
				<p> - http:// or https:// </p>
				<p> - sitename </p>
				<p> - site extension (at least 2 characters long) </p>
				
				<p> Valid URL will loook like: http://awesomefunctions.com </p>
				
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsURL"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsURL');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsURL');
					
					$('.Div_IsURL').html(d);
					
					$('.btn_Validate_IsURL').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsURL').val();
						if(frm.IsURL(d))
						{
							bs.ShowError ("Invalid URL ",$('.field_IsURL'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsURL - End]-->
			
		 
			<!--[IsNumber - Start]-->
			<span class="ScrollTo_IsNumber" id="IsNumber" ></span>
			<h3  class="page-header">Is Number</h3>
			<p>With this function you can easily check to see if input field contains number value or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsNumber(value) 

//Example
$('.btn_Validate_IsNumber').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsNumber').val();
 
 // Validate field
 if(frm.IsNumber(d))
 {
  //Show alert
  bs.ShowError ("Number value only ",$('.field_IsNumber'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsNumber" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsNumber">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsNumber"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsNumber');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsNumber');
					
					$('.Div_IsNumber').html(d);
					
					$('.btn_Validate_IsNumber').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsNumber').val();
						if(frm.IsNumber(d))
						{
							bs.ShowError ("Number value only ",$('.field_IsNumber'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsNumber - End]-->
			
			
			<!--[IsBetweenNumber - Start]-->
			<span class="ScrollTo_IsBetweenNumber" id="IsBetweenNumber" ></span>
			<h3  class="page-header">IsBetweenNumber</h3>
			<p>With this function you can easily check to see if input field value is between 2 numbers or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsBetweenNumber(value, 'startingvalue,endingvalue') 

//Example
$('.btn_Validate_IsBetweenNumberr').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsBetweenNumber').val();
 
 // Validate field
 if(frm.IsBetweenNumber(d, '2,5'))
 {
  //Show alert
  bs.ShowError ("Number has to be between 2 and 5 ",$('.field_IsBetweenNumber'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsBetweenNumber" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsBetweenNumber">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsBetweenNumber"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsBetweenNumber');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsBetweenNumber');
					
					$('.Div_IsBetweenNumber').html(d);
					
					$('.btn_Validate_IsBetweenNumber').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsBetweenNumber').val();
						if(frm.IsBetweenNumber(d, '2,5'))
						{
							bs.ShowError ("Number has to be between 2 and 5 ",$('.field_IsBetweenNumber'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsBetweenNumber - End]-->
			
			
			
			<!--[IsLength - Start]-->
			<span class="ScrollTo_IsLength" id="IsLength" ></span>
			<h3  class="page-header">Is Length</h3>
			<p>With this function you can easily check to see if input field value length is equal your allowed number or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsLength(value, Length) 

//Example
$('.btn_Validate_IsLength').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsLength').val();
 
 // Validate field
 if(frm.IsLength(d, 6))
 {
  //Show alert
  bs.ShowError ("Has to be 6 characters ",$('.field_IsLength'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsLength" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsLength">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsLength"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsLength');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsLength');
					
					$('.Div_IsLength').html(d);
					
					$('.btn_Validate_IsLength').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsLength').val();
						if(frm.IsLength(d, 6))
						{
							bs.ShowError ("Has to be 6 characters ",$('.field_IsLength'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsLength - End]-->
			
			
			
			<!--[IsMinLength - Start]-->
			<span class="ScrollTo_IsMinLength" id="IsMinLength" ></span>
			<h3  class="page-header">Is Min Length</h3>
			<p>With this function you can easily check to see if input field min value length is equals to your allowed number or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsMinLength(value, MinLength) 

//Example
$('.btn_Validate_IsMinLength').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsMinLength').val();
 
 // Validate field
 if(frm.IsMinLength(d,5))
 {
  //Show alert
  bs.ShowError ("Has to be at leaset 5 characters long ",$('.field_IsMinLength'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsMinLength" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsMinLength">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsMinLength"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsMinLength');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsMinLength');
					
					$('.Div_IsMinLength').html(d);
					
					$('.btn_Validate_IsMinLength').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsMinLength').val();
						if(frm.IsMinLength(d, 5))
						{
							bs.ShowError ("Has to be at leaset 5 characters long ",$('.field_IsMinLength'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsMinLength - End]-->
			
			
			
			
			<!--[IsMaxLength - Start]-->
			<span class="ScrollTo_IsMaxLength" id="IsMaxLength" ></span>
			<h3  class="page-header">Is Max Length</h3>
			<p>With this function you can easily check to see if input field max value length is equals to your allowed number or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsMaxLength(value, MaxLength) 

//Example
$('.btn_Validate_IsMaxLength').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsMaxLength').val();
 
 // Validate field
 if(frm.IsMaxLength(d,5))
 {
  //Show alert
  bs.ShowError ("Max of 8 characters long ",$('.field_IsMaxLength'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsMaxLength" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsMaxLength">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsMaxLength"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsMaxLength');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsMaxLength');
					
					$('.Div_IsMaxLength').html(d);
					
					$('.btn_Validate_IsMaxLength').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsMaxLength').val();
						if(frm.IsMaxLength(d, 8))
						{
							bs.ShowError ("Max of 8 characters long ",$('.field_IsMaxLength'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsMaxLength - End]-->
			
			
			<!--[IsMaxLength - Start]-->
			<span class="ScrollTo_IsRangeLength" id="IsRangeLength" ></span>
			<h3  class="page-header">Is Range Length</h3>
			<p>With this function you can easily check to see if input field value length is between your allowed length or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsRangeLength(value, 'StartLen, EndLen') 

//Example
$('.btn_Validate_IsRangeLength').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsRangeLength').val();
 
 // Validate field
 if(frm.IsRangeLength(d,'2,5'))
 {
  //Show alert
  bs.ShowError ("Allowed characters length is between 2 to 5  ",$('.field_IsRangeLength'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsRangeLength" aria-expanded="false"   >Example</a>			
			<div class="collapse" id="Collapse_IsRangeLength">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsRangeLength"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsRangeLength');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsRangeLength');
					
					$('.Div_IsRangeLength').html(d);
					
					$('.btn_Validate_IsRangeLength').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsRangeLength').val();
						if(frm.IsRangeLength(d, '2,5'))
						{
							bs.ShowError ("Allowed characters length is between 2 to 5  ",$('.field_IsRangeLength'))
						}
					})
				})
				</script> 
			</div> 
			<br><br> 
			<!--[IsRangeLength - End]-->
			
			
			<!--[IsEqualTo - Start]-->
			<span class="ScrollTo_IsEqualTo" id="IsEqualTo" ></span>
			<h3  class="page-header">Is Equal To</h3>
			<p>With this function you can easily check to see if value A matchs value B or not</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsEqualTo(value,EqualTo) 

//Example
$('.btn_Validate_IsEqualTo').click(function(e)
{
 //To clear all old alerts
 bs.ClearError();
 
 //Get the field value
 var d = $('.field_IsEqualTo').val();
 
 // Validate field
 if(frm.IsEqualTo(d,'awesomefunctions'))
 {
  //Show alert
  bs.ShowError ("Your input doesn't match. It should say: awesomefunctions",$('.field_IsRangeLength'))
 }
})
</pre>	
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_IsEqualTo" aria-expanded="false" >Example</a>			
			
			<div class="collapse" id="Collapse_IsEqualTo">
				<br><br>
				 
				<p>Try clicking the Validate Button before entering any data</p>
				
				<div class="Div_IsEqualTo"></div>
				
				
				<script>

            	$(document).ready(function()
            	{
					var d  = '';				
					d	+= bs.CreateInputField ('','','field_IsEqualTo');				
					d	+= '<br>';
					d	+= bs.CreateButton ('Validate','','btn-success btn_Validate_IsEqualTo');
					
					$('.Div_IsEqualTo').html(d);
					
					$('.btn_Validate_IsEqualTo').click(function(e)
					{
						bs.ClearError();
						var d = $('.field_IsEqualTo').val();
						if(frm.IsEqualTo(d, 'awesomefunctions'))
						{
							bs.ShowError ("Your input doesn't match. It should say: awesomefunctions",$('.field_IsEqualTo'))
						}
					})
				})
				</script> 

			</div> 
			<br><br> 

		<!--[IsEqualTo - End]-->
		
 		<!--[IsJSON - Start]-->
			<span class="ScrollTo_IsJSON" id="IsJSON" ></span>
			<h3  class="page-header">Is JSON</h3>
			<p>With this function you can easily check to see if the data is in json format or not. It will return true if your data is in json format. Otherwiser it will return false.</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
frm.IsJSON(DataValue) 

//Example 1
var json_check = frm.IsJSON("I love awesome functions");
console.log(json_check); // false



//Example 2
var data = {site:"http://awesomefunctions.com",user: "codewithmark"};

var json_check = frm.IsJSON(data);

console.log(json_check); // true


</pre>	
			 
		<!--[IsEqualTo - End]-->



			<br><br>
 		</div>
 		<!--[Left Content Column - End]-->

		<!--[Right Side Bar - Start]-->
		<div class="col-md-3  ">			
			<div  class="sidebar-nav-fixed pull-right affix" style="max-height:100vh; overflow: auto;">
				
			
				<p class="lead text-center">Functions</p>
				<div class="list-group">
					
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsEmpty" href="#IsEmpty">IsEmpty</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsAlphaNumeric" href="#IsAlphaNumeric">Is Alpha Numeric</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsNoSpaces" href="#IsNoSpaces">Is No Spaces</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsEmail" href="#IsEmail">Is Email</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsURL" href="#IsURL">Is URL</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsNumber" href="#IsNumber">Is Number</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsBetweenNumber" href="#IsBetweenNumber">Is Between Number</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsLength" href="#IsLength">Is Length</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsMinLength" href="#IsMinLength">Is Min Length</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsMaxLength" href="#IsMaxLength">Is Max Length</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsRangeLength" href="#IsRangeLength">Is Range Length</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsEqualTo" href="#IsEqualTo">Is Equal To</a>
					<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_IsJSON" href="#IsJSON">Is JSON</a>
					
				<br><br>
				</div>
				<br><br>
			</div>
			
		</div>
		
		
		<!--[Right Side Bar - End]-->
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->

<?php include('footer.php') ?>
	
</body>

</html>