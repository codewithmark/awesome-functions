<!DOCTYPE html>
<html>
<head>

	<title>Awesome Functions - JS Library</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This Awesome Functions  library has a lot of easy to use functions that will help you build awesome client side web applications faster then you can imagine">

	<meta name="author" content="Code With Mark">
	<meta name="authorUrl" content="https://www.awesomefunctions.com">
	
	<?php include('header.php') ?>

	
	
</head>
 
<body>
	
<?php include("nav-top.php") ?>

<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row">
		
		<!--[Content - Start]-->
		<div class="container">
			
			<h1  class="  text-center">Awesome Functions</h1>
			<img  src="<?php echo URL_View?>/img/awesome-functions.jpg" style="height:100px; width:100px" class="img-responsive center-block"/>
			<h4  class="  text-center">Let's Build Something Awesome</h4>
			
			<br> <br> 

			<p>This JS library has a lot of easy to use functions that will help you build awesome client side web applications faster</p>
	 
			<br> 
			
			<div class="form-group">
				
				<b class="center-block" style="font-size:22px;">API CDN</b>
				<br> 
				<div class="input-group">
					<div class="input-group-addon">Mini</div>
					<input type="text" class="form-control" value="https://cdn.awesomefunctions.com/awesome-functions.min.js" onclick="this.select();">
					<input type="text" class="form-control" value="https://cdn.apidelv.com/libs/awesome-functions/awesome-functions.min.js" onclick="this.select();">
				</div>
				<br>
				<!--
				<div class="input-group">
					<div class="input-group-addon">Full</div>
					<input type="text" class="form-control" value="https://apimk.com/cdn/awesome-functions/awesome-functions.js" onclick="this.select();">
				</div>
 				-->
			</div>
 			
 			<!--
			<div class="text-center">
				<a href="https://raw.githubusercontent.com/codewithmark/awesome-functions/master/awesome-functions-min.js" target="_blank"  follow="yes" class=" btn btn-lg btn-success fa fa-download " > Download (Mini)</a>
			</div>
			-->
			
			<br><br>
 
			<!--[About Section - Start]-->
			<section  >
				<h2 class="page-header">About</h2>
				<div class="row">
					<div class="col-md-4 col-sm-4">
						<p>
							Current Version: 2.17.4.19
						</p>
					</div>
					<div class="col-md-4 col-sm-4">
						<p>
						  My name is Mark Kumar and I created this. If you want to learn more about how to build web applications easily and faster, check out  <a href="http://codewithmark.com/" follow="yes">Code With Mark</a>   
						</p>
					</div>
					<div class="col-md-4 col-sm-4">
						<p>
							If you like to contribute or report any bugs, go over to  <a href="https://github.com/codewithmark/awesome-functions" >GitHub</a> 
						</p>
					</div>
				</div>
			</section>
			<!--[About Section - End]-->
			
			<!--[Thanks Section - Start]-->
			<section  >
				<h2 class="page-header">Thanks To</h2>
				<div class="row">
					<div class="col-md-4 col-sm-4">
						<p>
							HUGE thanks to <a href="https://apimk.com/" follow="yes">API MK</a> for it's help with <a href="http://awesomefunctions.com/api">API Functions</a>
						</p>
					</div>
					<div class="col-md-4 col-sm-4">
						<p>
							<a href="http://momentjs.com/docs/#/displaying/">Moment JS</a> for help with <a href="http://awesomefunctions.com/jquery#FormatDateTime">Format Date Time</a> function.
						</p>

						<p>
							<a href="https://github.com/myclabs/jquery.confirm">My C-Labs Guys</a> for help with <a href="http://awesomefunctions.com/jquery#ConfirmAlert">Confirm Alert</a> function.
						</p>

						
					</div>
					<div class="col-md-4 col-sm-4">
						<p>
							<a href="https://www.cloudflare.com/"> CloudFlare</a> and 
							<a href="https://apidelv.com/" rel="follow" target="_blank"> API Delv </a> 
							<i class="fa fa-external-link" style="font-size:10px; Position:relative; top: -5px;"></i> 
							for providing the fastest way to load Awesome Functions JS Library.
						</p>
					</div>
				</div>
			</section>
			<!--[Thanks Section - Start]-->
		</div>
		<!--[Content - End]-->
		
 
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->


<?php include('footer.php') ?>
 
</body>

</html>