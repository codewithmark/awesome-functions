<!DOCTYPE html>
<html>
<head>

	<title>PHP - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This JS library has a lot of useful and powerful JS and PHP functions that will help you build awesome client side web applications">
 
	
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{
		//console.clear(); 
		$('[data-toggle="tooltip"]').tooltip();
				
		//--->microtime - start
		var strMicrotime = '';
		strMicrotime +='var d = php.microtime() //Output---> ' + php.microtime() ;
		strMicrotime +='<br><br>';
		strMicrotime +='var d = php.microtime(true)) //Output---> ' + php.microtime(true) ;
 		$('.Results_Microtime').html(	strMicrotime);
		//--->microtime - end
		
		//--->uniqid - start
		var strUniqid = '';
		strUniqid +='var d = php.uniqid() //Output---> ' + php.uniqid() ;
		strUniqid +='<br><br>';
		strUniqid +='var d = php.uniqid("foo") //Output---> ' + php.uniqid("foo") ;
 		$('.Results_Uniqid').html(	strUniqid);
		//--->uniqid - end 
		
	});
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row"> 

		<div class="col-md-9">
		<h1 class="text-center">PHP</h1>	
	 

			<!--[Microtime - Start]-->
			<span class="ScrollTo_Microtime" id="Microtime" ></span>
			<h3  class="page-header">microtime</h3>
			<p>Like in php, this function returns the current Unix timestamp with microseconds.</p>		 
			<b>Usage</b>			 
<pre class="bg-success ">
var d = php.microtime();
var d = php.microtime(true); 
</pre>
			 <p>You can assign this to a variable like you see above and use it later on.</p>
	 		
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_Microtime" aria-expanded="false" aria-controls="Collapse_Microtime" >Example</a>			
			<div class="collapse" id="Collapse_Microtime">
				<br>				 
				<pre class="Results_Microtime "></pre>
				<br>
						<b>Note:</b>
		 			<p>Returns the string &quot;microsec sec&quot; by default, where sec is the number of seconds since the Unix Epoch (0:00:00 January 1, 1970 GMT), and microsec is the microseconds part. If the&nbsp;<em>get_as_float</em>&nbsp;parameter is set to TRUE, it returns a float representing the current time in seconds since the Unix epoch accurate to the nearest microsecond</p>
 
			</div> 
			<br><br> 
			<!--[Microtime - End]-->

			<!--[uniqid - Start]-->
			<span class="ScrollTo_Uniqid" id="Uniqid"  ></span>
			<h3  class="page-header">uniqid</h3> 
			<p>Like in php, this function  generates a unique ID based on the microtime (current time in microseconds)</p> 
		 
		 
			<b>Usage</b>			 
<pre class="bg-success ">
var d = php.uniqid();
var d = php.uniqid("foo");
</pre>
			<p>You can assign this to a variable like you see above and use it later on.</p>
	 		
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_Uniqid" aria-expanded="false" aria-controls="Collapse_Uniqid" >Example</a>			
			<div class="collapse" id="Collapse_Uniqid">
				<br>	
				<pre class="Results_Uniqid "></pre>
				<br>
		 
			</div> 
			<br><br>
			<!--[uniqid - End]-->

		<!--[str_replace - Start]-->
		<span class="ScrollTo_StrReplace" id="StrReplace" ></span>
		<h3  class="page-header">str_replace</h3>
		 <p>The str_replace() function finds and replaces some characters with some other characters in a string.</p>

			<b>Usage</b>			 
<pre class="bg-success ">
php.str_replace(find,replace,string)
</pre>

			<br> 
			<a class="btn btn-primary" role="button" data-toggle="collapse" href="#Collapse_Str_Replace" aria-expanded="false" aria-controls="Collapse_Str_Replace" >Examples</a>	
			
			<div class="collapse" id="Collapse_Str_Replace">
			<br>		
			<b>Example 1</b>		
<pre>
php.str_replace("world","Mark","Hello world!") //output --> Hello Mark!
</pre>
			<br> 
		
			<b>Example 2</b>	
<pre>
Arr1 = ['Code','With']

Arr2 = ['Awesome','Functions']

String = "This is Code With JS Library."

php.str_replace(Arr1,Arr2,String) //output --> This is Awesome Functions JS Library.
</pre>

			<br>
		
			<b>Example 3</b>	
<pre>
var strDIV = '&lt;div>{Code}&lt;/div>';
strDIV += '&lt;div class="{ReplaceClassName}"> &lt;/div>';

Arr1 = ['{Code}','{ReplaceClassName}'];
Arr2 = ['Awesome Functions', 'AwesomeFunctionClass'];

var Data = php.str_replace(Arr1,Arr2,strDIV) 

//Out put to body or whatever element id you want to
$('body').html(Data);

$('#MyID').html(Data);

$('.MyClassName').html(Data);

//Will output this
&lt;div>Awesome Functions&lt;/div>
&lt;div class="AwesomeFunctionClass">&lt;/div>

</pre>
				</div>
				<br><br><br><br>		

			<!--[str_replace - End]-->


		 	

		 	<!--[Decode - Start]-->
			<span class="ScrollTo_Encode"  id="Decode" ></span>
			<h3  class="page-header" >Decode </h3>
			<p>This will Decode your php base64_encode() string  </p>
			<p></p>
			<b>Usage</b>			 
<pre class="bg-success ">
//Syntax 
php.Decode(StringVal)

php.Decode("Y29kZXdpdGhtYXJr")
 
//--->Out put will
codewithmark
</pre>
			<!--[Decode - End]-->	

<p>&nbsp;</p>

<p><strong>Ideal usage</strong></p>

<p>Let&#39;s suppose you want to add an extra layer of security to your user&#39;s password&nbsp;</p>

<p>In your php, encode your password and save it in a cookie:&nbsp;setcookie(&quot;user_password&quot;,base64_encode (&quot;password&quot;)&nbsp;&nbsp;);</p>

<p>On your client side javascript, you can decode the password like this:</p>

<p>1) Read the cookie: var passwd = c.Get(&quot;user_password&quot;);</p>

<p>2) php.Decode(passwd)</p>

<p>&nbsp;</p>


		</div>
		
		<!--[Right Side Bar - Start]-->
		<div class="col-md-3  ">			
			<div  class="sidebar-nav-fixed pull-right affix">
				
			
			<p class="lead text-center">Functions</p>
			<div class="list-group">
				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Microtime" href="#Microtime">microtime</a>
				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Uniqid" href="#Uniqid">uniqid</a>
				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_StrReplace" href="#StrReplace">str_replace</a>			 
				<a  class="list-group-item ScrollToElement"  ScrollObjID="ScrollTo_Decode" href="#Decode">Decode</a>
			</div>
			</div>
			
		</div>
		
		
		<!--[Right Side Bar - End]-->
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->

<?php include('footer.php') ?>
	
</body>

</html>