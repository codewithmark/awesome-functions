<!DOCTYPE html>
<html>
<head>

	<title>API - Awesome Functions</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="This JS library has a lot of useful and powerful JS and PHP functions that will help you build awesome client side web applications">
 
<?php include('header.php') ?>
 
	<script type="text/javascript">  
	$(document).ready(function()
	{
		//console.clear(); 
		$('[data-toggle="tooltip"]').tooltip(); 
		
		//Get user loc info
		api.UserLoc().then(function (data) 
		{	
			var strDiv = JSON.stringify(data, null,2);
			$('.Results_UserLoc').html(strDiv);
		}); 
	 
 		
		
	});
	</script>
	
	
</head>
 
<body  >
	
<?php include("nav-top.php") ?>
	<div style=' padding:30px'></div>
	

<!--[Container - Start]-->
<div class="container"  >
	
	<!--[Row - Start]-->
	<div class="row"> 

		<div class=" ">
		<h1 class="text-center">API</h1>	
		<p  class="text-center">These functions have dependency on jQuery</p> 

			<!--[UserLoc - Start]-->
			<span class="ScrollTo_UserLoc" id="UserLoc" ></span>
			<h3  class="page-header">UserLoc</h3>
			 		<p>This will provide  geolocation info of your visitors such as&nbsp;latitude, longitude, city, region, country and timezone.&nbsp;</p> 
		 
			<b>Usage</b>			 
<pre class="bg-success ">
api.UserLoc().then(function (data) 
{
 console.log(data)
});
</pre> 
			<a class="btn btn-primary BtnUserLoc" role="button" data-toggle="collapse" href="#Collapse_UserLoc" aria-expanded="false" aria-controls="Collapse_UserLoc" >Results</a>			
			<div class="collapse" id="Collapse_UserLoc">
				<br>
				<div class="bg-success code-result userloc " style="display:none;"></div>
				<pre class="Results_UserLoc "></pre>
				<br> 
			</div>
			<!--[UserLoc - End]--> 
				
				
	 
			<h3>Best practice</h3>

			<p>Call this function on page load and save the data&nbsp;in a div,&nbsp;cookie, or any other method you would like to.&nbsp;This way the info is ready for you to use.</p>

			<p>Otherwise, you will have to wait for the api call to finish which could result in unexpected response.</p>

			<br><br><br> 
			
			

		</div>
		
		 
		
		
	</div>
	<!--[Row - End]-->
	
</div>
<!--[Container - End]-->
	
<?php include('footer.php') ?>

</body>

</html>